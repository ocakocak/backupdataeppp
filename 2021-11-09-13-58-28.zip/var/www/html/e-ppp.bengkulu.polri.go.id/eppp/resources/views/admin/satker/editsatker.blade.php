@extends('layouts.backendadmin')

@section('content')
<div class="card card-primary">
     <a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="{{ route('datasatker') }}">
        <i class="fas fa-arrow-circle-left"></i></i> Kembali
    </a>
    <div class="card-header">
        <h4 style="color:#6a381f">Formulir Edit Satker</h4>
    </div>
    <div class="card-body p-0">
        <form action="{{ route('updatesatker', $data_satker->id_satker) }}" method="post" enctype="multipart/form-data">
            <div class="card-body">
                @csrf
                @method('patch')
                <div class="row">
                    <div class="col-md-12 row">
                        <div class="col-md-4 form-group">
                            <label>Nama Satker</label>
                            <input required type="text" name="satkers" value="{{$data_satker->satkers}}" class="form-control">
                        </div>
                        @if(auth()->user()->id_aktor==1)
                        <div class="col-md-4 form-group">
                            <label>Kesatuan</label>
                            <div class="row ml-1" style="height:40px">
                                <select required class="select" id="id_kesatuan" name="id_kesatuan">
                                    <div>
                                        <option value="{{$data_satker->id_kesatuan}}">{{$data_satker->kesatuan->kesatuans}}</option>
                                        @if ($data_kesatuan != null)
                                        @foreach ($data_kesatuan as $djs)
                                        <option value="{{$djs->id_kesatuan}}">{{$djs->kesatuans}}</option>
                                        @endforeach
                                        @endif
                                    </div>
                                </select>
                            </div>
                        </div>
                        @else
                        <input type="hidden" value="{{$data_satker->id_kesatuan}}" name="id_kesatuan" class="form-control" hidden>
                        @endif
                    </div>
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-polda mr-1" style="color:white" type="submit"><i class="fas fa-save"></i></button>
                <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
            </div>
        </form>
    </div>

</div>
@endsection
