@include('templateuser.header')

@include('templateuser.topnav')

@yield('content')

@include('templateuser.footer')