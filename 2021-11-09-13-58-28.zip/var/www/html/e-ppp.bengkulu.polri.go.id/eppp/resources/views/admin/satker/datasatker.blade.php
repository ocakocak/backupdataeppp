@extends('layouts.backendadmin')

@section('content')
<div class="card card-primary">
    <br>
    <h4 style="color:#6a381f;text-align:center">Data Satker</h4>
    <hr>
    <div class="card-body p-0">
    @include('alert')
        <div class="row col-md-12">
            <div class="col-md-9" align="left">
                <a href="{{ route('tambahsatker')}}" class="btn btn-polda" style="color:white;"><i class="fas fa-user-plus"></i>
                    Tambah Satker
                </a>
            </div>
            <div class="col-md-3" align="right">
                <br>
                <br>
                <br>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tbody>
                        <tr style="width:100px">
                            <th style="width:5px">No</th>
                            <th style="width:100px">Satker</th>
                            <th style="width:100px">Kesatuan</th>
                            <th style="width:200px"></th>
                        </tr>
                        @if ($data_satker != null)
                        @foreach ($data_satker as $ker)
                        <tr>
                            <td class="align-top" style="width:5px"><br>{{$loop->iteration}}</td>
                            <td class="align-top" style="width:100px"><br>{{ $ker->satkers }}</td>
                            <td class="align-top" style="width:100px"><br>{{ $ker->kesatuan->kesatuans }}</td>
                            <td class="align-top" style="width:150px">
                                <br><a style="color:white; vertical-align: middle;" href="{{ route('editsatker', $ker->id_satker) }}" class="btn btn-polda btn-action mr-1" style=" color:white;" data-toggle="tooltip" title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i> </a>
                                <a href="{{ route('hapussatker', $ker->id_satker) }}" class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus satker?')" data-toggle="tooltip" title=""><i class="fas fa-trash"></i> </a>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

@endsection
