@extends('layouts.backendadmin')

@section('content')
<div class="card card-primary">
    <br>
    	 <div class="row col-md-12">
            <div class="col-md-3" align="left">
                <a href="{{ route('cetakadmin') }}" class="btn btn-polda" style="color:white;"><i
                        class="fas fa-print"></i>
                    Cetak
                </a></div>
		<div class="col-md-6" align="center">
		<h4 style="color:#6a381f;text-align:center">Data Admin</h4>
		</div>
	 </div>
    <hr>
@include('alert')
    <div class="card-body p-0">
        <div class="row col-md-12">
            <div class="col-md-9" align="left">
                <a href="{{ route('tambahadmin') }}" class="btn btn-polda" style="color:white;"><i
                        class="fas fa-user-plus"></i>
                    Tambah Admin
                </a></div>
            <div class="col-md-3" align="right">
            </div>
        </div><br>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tbody>
                        <tr style="width:100px">
                            <th style="width:5px">No</th>
                            <th style="width:150px">Kesatuan</th>
                            <th style="width:150px">Username</th>
                            <th style="width:150px">Password</th>
			    <th style="width:50px"></th>
                        </tr>
                        @if ($data_admin != null)
                        @foreach ($data_admin as $key => $item)
                        <td class="align-top" style="width:5px"><br>{{$loop->iteration}}</td>
                        <td class="align-top" style="width:100px"><br>{{ $item->kesatuan->kesatuans }}</td>
                        <td class="align-top" style="width:100px"><br>{{ $item->username }}<br></td>
			<td class="align-top" style="width:100px"><br>{{ $item->dekripsi }}<br></td>
                        <td class="align-top" style="width:150px">
                            <br><a style="color:white" href="{{ route('editadmin', $item->id) }}"
                                class="btn btn-polda style=" color:white;"btn-action mr-1" data-toggle="tooltip"
                                title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i> </a>
                            <a href="{{ route('hapusadmin', $item->id) }}"
                                class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus admin?');" data-toggle="tooltip"
                                title=""><i class="fas fa-trash"></i> </a>
                        </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
                <div class="row col-md-12">

                    <div class="col-md-3" align="left">
                    </div>
                </div><br>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

@endsection
