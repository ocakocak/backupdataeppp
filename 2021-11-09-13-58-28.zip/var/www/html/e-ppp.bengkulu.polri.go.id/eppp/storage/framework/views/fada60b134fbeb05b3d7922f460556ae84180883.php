<?php $__env->startSection('content'); ?>
                <div class="card card-primary">
<a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('datapersonil')); ?>">
                        <i class="fas fa-arrow-circle-left"></i></i> Kembali
                    </a>
                    <div class="card-header">
                        <h4 style="color:#6a381f">Formulir Tambah Data Personel</h4>
                    </div>
                    <div class="card-body p-0">
                        <form action="<?php echo e(route('tambahdatapersoniltabel')); ?>" method="post"
                            enctype="multipart/form-data">
                            <div class="card-body">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12 row">
                                        <div class="col-md-6 form-group">
                                            <label>Nama</label>
                                            <input type="text" name="nama" class="form-control" required>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>NRP/NIP</label>
                                            <input type="text" name="nrpnip" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12 row">
                                        <div class="col-md-4 form-group">
                                            <label>Pangkat</label>
                                            <select class="form-control" id="pangkat" name="pangkat" required>
                                                <option disabled selected value="">-Pilih Pangkat-</option>
                                                <?php $__currentLoopData = $data_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($p->id_pangkat); ?>"><?php echo e($p->pangkats); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <label>Jabatan</label>
                                            <input type="text" name="jabatan" class="form-control" required>
                                        </div>
                                        <?php if(auth()->user()->id_aktor==1): ?>
                                        <div class="col-md-4 form-group">
                                            <label>Kesatuan</label>
                                            <select class="form-control" id="kesatuan" name="kesatuan" required>
						<option disabled selected value="">-Pilih Kesatuan-</option>
                                                <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($k->id_kesatuan); ?>"><?php echo e($k->kesatuans); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-polda mr-1" style="color:white"type="submit"><i class="fas fa-save"></i></button>
                        <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
                    </div>
                    </form>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/personil/tambahpersonil.blade.php ENDPATH**/ ?>