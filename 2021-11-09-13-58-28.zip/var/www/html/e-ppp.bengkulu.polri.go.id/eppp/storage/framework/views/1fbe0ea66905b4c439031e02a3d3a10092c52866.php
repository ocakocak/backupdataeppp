<?php $__env->startSection('content'); ?>
    <div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
        <div class="card-body p-0">
       		<div class="card-body">
                <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <h2 class="text-center"><?php echo e($judul); ?></h2>
                <hr>
                <p style="text-align: center;font-family:Koh Santepheap; font-size:25px;color:#9d0208; font-weight:bold">Data Berita</p>
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <tbody>
                            <tr style="width:100px" style="text-align: center;">
                                <th rowspan="2">No</th>
                                <th rowspan="2">Judul</th>
                                <th rowspan="2">Isi</th>
				<th rowspan="2">Gambar</th>
                                <th colspan="2" style="text-align: center;">Aksi</th>
                            </tr>
                            <tr>
                                <th>Edit</th>
                                <th>Hapus</th>
                            </tr>
                            <?php if($berita != null): ?>
                            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"> <?php echo e($loop->iteration); ?> </td>
                                <td><?php echo $p->judul; ?></td>
                                <td style="text-align:justify">
				    <a>Lihat isi berita.<a>
                                </td>
				<td style="text-align:justify" class="pt-3 pb-3">
                                <?php if($p->gambar != "logo.png"): ?>
                                    <img src="<?php echo e(asset('storage/berita/'.$p->gambar)); ?>" width="280" class="rounded mx-auto d-block">
                                    <?php else: ?>
                                    <img src="<?php echo e(('logo.png')); ?>" width="280" class="rounded mx-auto d-block">
                                    <?php endif; ?>

				</td>
                                <td>
                                    <a href="<?php echo e(route('editberita', $p->id_berita)); ?>">
                                        <button class="btn btn-polda mx-auto" style="color: white;"><i class="fas fa-edit"></i></button>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('hapusberita', $p->id_berita)); ?>">
                                        <button class="btn btn-danger mx-auto" onclick="return confirm('Yakin ingin menghapus berita?');"><i class="fas fa-trash-alt"></i></button>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <hr>
                <p style="text-align: center;font-family:Koh Santepheap; font-size:25px;color:#9d0208; font-weight:bold">Tambah Berita</p>
                <form action="<?php echo e(route('tambahberita')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col mx-auto">
                        <div class="form-group col-md-8 mx-auto">
                            <label>Judul Berita</label>
                            <input type="text" required id="judul" name="judul" class="form-control" required></input>
                        </div>
                        <div class="form-group col-md-8 mx-auto">
                            <label>Isi Berita</label>
                            <textarea id="isi" required rows="3" name="isi" class="form-control" required></textarea>
                        </div>
                        <div class="form-group col-md-8 mx-auto">
                            <label>Gambar Berita</label>
                            <input type="file" id="gambar" name="gambar" class="form-control"></input>
                        </div>
                        <div class="mx-auto" style="text-align: center;">
                            <button class="btn btn-polda mx-auto" style="color: white;" type="submit">Tambah Berita</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/sigasi/landing/berita.blade.php ENDPATH**/ ?>