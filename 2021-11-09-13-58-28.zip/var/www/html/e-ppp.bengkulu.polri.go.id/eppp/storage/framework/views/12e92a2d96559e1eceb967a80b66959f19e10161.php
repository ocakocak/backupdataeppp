<?php $__env->startSection('content'); ?>
<div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
    <div class="card-body p-0">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <p class="text-center"><?php if(auth()->user()->id_aktor==1): ?>
                <h4 class="text-center" style="color:black">Selamat datang, Super Admin!</h4>
                <?php elseif(auth()->user()->id_aktor==2): ?>
                <h4 class="text-center" style="color:black">Selamat datang, Admin!</h4>
                <?php elseif(auth()->user()->id_aktor==3): ?>
                <h4 class="text-center" style="color:black">Selamat datang, User!</h4>
                <?php elseif(auth()->user()->id_aktor==4): ?>
                <h4 class="text-center" style="color:black">Selamat datang, Admin Info!</h4>
                <?php endif; ?></p>
            <hr>

            <div class="col ml-3">
                <div class="row">
                    <div class="card shadow h-100 py-2" style="background-color:#8a040c;color:white">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-uppercase mb-1">
                                        <a style="color:white" href="<?php echo e(route('datapersonil')); ?>" class="stretched-link"
                                            style="color: rgb(105, 5, 0);">Jumlah Personel Terdata</a>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"> <?php echo e($data_personil); ?> Personel
                                    </div>
                                </div>
                                <div class="col-auto ml-3">
                                    <i class="fas fa-file-alt fa-5x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow h-100 py-2 ml-3" style="background-color:#ac050f;color:white">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-uppercase mb-1">
                                        <a style="color:white" href="<?php echo e(route('datasigasiprestasi')); ?>" class="stretched-link"
                                            style="color: #6e0d25;">Jumlah Prestasi Terdata</a>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"> <?php echo e($data_prestasi); ?> Prestasi
                                    </div>
                                </div>
                                <div class="col-auto ml-3">
                                    <i class="fas fa-file-alt fa-5x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow h-100 py-2 ml-3" style="background-color:#c10612;color:white">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-uppercase mb-1">
                                        <a style="color:white" href="<?php echo e(route('datasigasipenghargaan')); ?>"
                                            class="stretched-link" style="color: #6a381f;">Jumlah Penghargaan
                                            Terdata</a>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"> <?php echo e($data_penghargaan); ?>

                                        Penghargaan</div>
                                </div>
                                <div class="col-auto ml-3">
                                    <i class="fas fa-file-alt fa-5x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <img src='salam.png' class="mx-auto" style="width: 500px;">
    <br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/superadmin/dashboard.blade.php ENDPATH**/ ?>