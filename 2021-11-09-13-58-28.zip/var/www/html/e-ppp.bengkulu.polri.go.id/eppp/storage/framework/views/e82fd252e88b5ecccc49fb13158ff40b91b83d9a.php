<?php $__env->startSection('content'); ?>
<div class="row col-md-12">
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('filtersigasi')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <h6 style="color:#6a381f;">Cari Berdasarkan</h6><br>
                    <?php if(auth()->user()->id_aktor == 1): ?>
                    <div class="form-group">
                        <label>Pilih Kesatuan</label>
                        <select class="form-control" name="id_kesatuan">
                            <option></option>
                            <?php if($data_kesatuan != null): ?>
                            <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dk->id_kesatuan); ?>"><?php echo e($dk->kesatuans); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
                            <?php $data_satker = App\Models\Satker::all(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <?php elseif(auth()->user()->id_aktor == 2 && auth()->user()->id_kesatuan == 11): ?>
                    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
                            <?php $data_satker = App\Models\Satker::where('id_kesatuan',11)->get(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
		    <?php elseif(auth()->user()->id_aktor == 2 && auth()->user()->id_kesatuan != 11): ?>
                    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
                            <?php $data_satker = App\Models\Satker::where('id_kesatuan',auth()->user()->id_kesatuan)->get(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilih Pangkat</label>
                        <select class="form-control" name="id_pangkat">
                            <option></option>
                            <?php if($data_pangkat != null): ?>
                            <?php $__currentLoopData = $data_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dp->id_pangkat); ?>"><?php echo e($dp->pangkats); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="input-group" id="dari2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Dari
                                </div>
                            </div>
                            <input name="from_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group" id="sampai2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Sampai
                                </div>
                            </div>
                            <input name="to_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <div class="input-group">
                            <input type="text" class="form-control daterange-cus" name="namapersonil">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>NRP/NIP</label>
                        <div class="input-group">
                            <input type="text" class="form-control daterange-cus" name="nrpnip">
                        </div>
                    </div>
                    <?php if(auth()->user()->id_aktor == 1): ?>
                    <div class="form-group">
                                                                <label>Jenis Penghargaan</label>
                                                                <select class="form-control"
                                                                    name="jenis_penghargaan">
                                                                    <option value="" style="color: grey;" disabled
                                                                        selected>-Pilih Jenis Penghargaan-</option>
                                                                    <option value="KPLB">KPLB
                                                                    </option>
                                                                    <option value="KPLBA">KPLBA</option>
                                                                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                                                                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                                                                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                                                                </select>
                                                            </div>
                    <?php endif; ?>
                    <br>
                    <div class="col-md-12">
                    <button value="submit3" type="submit" name="submit" class="btn btn-polda col-md-12"
                        style="color:white;float:left"><i class="fas fa-search"></i> Cari</button>
                    </div>
                    <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==2): ?>
                    <br>
                    <br>
                    <div class="col-md-12">
                    <button value="submit1" type="submit" name="submit" class="btn btn-success col-md-12"
                        style="color:white;float:left"><i class="far fa-file-excel"></i> Excel</button>
                    </div>
                    <br>
                    <br>
                    <div class="col-md-12">
                    <button value="submit2" type="submit" name="submit" class="btn btn-polda col-md-12"
                        style="color:white;float:left"><i class="fas fa-print"></i> Cetak</button>
                    </div>
                    <?php endif; ?>
                    </div>
            </form>
        </div>
    </div>
    <div class="col-md-9 card card-primary">
 <div class="card-body p-0">
            <div class="row col-md-12">
<div class="mt-3 col-md-12">
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

                <div class="col-md-12" align="center">
                    <h4 style="color:#6a381f;text-align:center"><br>Data Penghargaan Personel</h4>
                </div>
            </div>
            <hr>

            <div class="card-body p-0">
                <!-- <iframe src="<?php echo e(asset('storage/filebuktipenghargaan/pdf.pdf')); ?>" width="1280" height="720"></iframe> -->
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                            <tr style="width:1000px">
                                <th style="width:5px">
                                    No
                                </th>
                                <th style="width:50px">Tanggal Input</th>
                                <th style="width:100px">Nama</th>
                                <th style="width:100px">Pangkat</th>
                                <th style="width:100px">NRP/NIP</th>
                                <th style="width:100px">Jabatan</th>
                                <th style="width:100px">Kesatuan</th>
                                <th style="width:100px">Penghargaan</th>
                                <th style="width:300px">Pemberi Penghargaan</th>
                                <th style="width:240px">Keterangan Penghargaan</th>
                                <th style="width:150px">Evidence</th>
                                <th></th>
                                <!-- <th style="width:100px">Status</th> -->
                                <!-- <th>Action</th> -->
                            </tr>
                            <?php $no = 1; ?>
                            <?php if($data_sigasi != null): ?>
                            <?php $__currentLoopData = $data_sigasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dg->jenis_penghargaan != null): ?>
                            <tr style="width:100px">
                                <td class="align-top" style="width:5px"><br>
                                    <?php echo e($no++); ?>

                                </td>
                                <td style="width:50px" class="align-top text-justify"><br>
                                    <?php echo e(date('d-m-Y', strtotime($dg->tanggal_input))); ?> </td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->nama); ?> </td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->pangkat->pangkats); ?></td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->nrpnip); ?></td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->jabatan); ?>

                                </td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->kesatuan->kesatuans); ?>

                                </td>
                                <td style="width:100px" class="align-top"><br><?php echo e($dg->jenis_penghargaan); ?>


                                </td>
                                <td style="width:300px" class="align-top" style="font-weight:bold"><br><?php echo e($dg->sumber); ?>

                                </td>
                                <td style="width:240px" class="align-top" style="font-weight:bold"><br>
                                <?php echo e($dg->keterangan_penghargaan); ?>

                                </td>
                                <td style="width:100px" class="align-top " style="font-weight:bold"><br>
                                    <center>
                                        <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==2 ||
                                        auth()->user()->id_aktor==3): ?>
                                        <button data-toggle="modal" data-target="#tambahBukti<?php echo e($dg->id_sigasi); ?>"
                                            style="color: white;" class="btn btn-polda">
                                            <i class="far fa-eye"></i></button>
                                        <div class="modal fade" width="60" id="tambahBukti<?php echo e($dg->id_sigasi); ?>"
                                            tabindex="-1" aria-labelledby="tambahBukti<?php echo e($dg->id_sigasi); ?>Label"
                                            aria-hidden="true">
                                            <div class="modal-dialog mx-auto">
                                                <!-- <div class="card mx-auto pt-3 pl-3" style="width: 40rem;"> -->
                                                <div class="modal-content mx-auto">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="tambahBukti<?php echo e($dg->id_sigasi); ?>Label">
                                                            Bukti Penghargaan</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('tambahbuktipenghargaan')); ?>" method="post"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                                class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">Nama Penghargaan</label>
                                                                <input type="text" class="form-control" readonly
                                                                    value="<?php echo e($dg->nama_penghargaan); ?>">
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label class="col-sm-3"
                                                                    style="float:left;font-size: 15px;">File
                                                                    Bukti</label>
                                                                <?php $databukti=App\Models\BuktiPenghargaan::where('id_sigasi',$dg->id_sigasi)->get(); ?>
                                                                <?php $__currentLoopData = $databukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <a class="col-sm-10" style="color:black"
                                                                    href="<?php echo e(route('lihatbuktisigasi2', $databukti->id_bukti_penghargaan)); ?>"><?php echo e($databukti->file_bukti_penghargaan); ?></a>
                                                                <div class="col-sm-1">
                                                                    <i class="fas fa-download"></i>
                                                                </div>
							<?php if(auth()->user()->id_aktor==1): ?>	
								<a onclick="return confirm('Apakah Anda yakin ingin menghapus file bukti penghargaan?')" href="<?php echo e(route('hapusbuktipenghargaan', $databukti->id_bukti_penghargaan)); ?>">
                                                                        <i class="fas fa-trash-alt"></i>
                                                                </a>
							<?php endif; ?>
                                                                <hr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
							<?php if(auth()->user()->id_aktor == 1): ?>
                                                            <div class="form-group row mr-3 ml-3">

                                                                <label style="font-size: 15px;">Tambah File Bukti
                                                                    Penghargaan</label>
                                                                <input name="file_bukti_penghargaan[]" type="file"
                                                                    class="form-control" multiple="true">
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3 float-right">
                                                                <button class="btn btn-polda mr-1" style="color: white;"
                                                                    type="submit">Tambah File</button>
                                                            </div>
							<?php endif; ?>
                                                        </form>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </center>
                                </td>
                                <td class="align-top" style="width:150px">
                                    <?php if(auth()->user()->id_aktor==1): ?>
                                    <br><a href="<?php echo e(route('editsigasipenghargaan', $dg->id_sigasi)); ?>"
                                        class="btn btn-polda btn-action trigger--fire-modal-1"><i class="fas fa-edit"></i> </a>
				    <br><br><a href="<?php echo e(route('hapussigasipenghargaan', $dg->id_sigasi)); ?>"
                                        class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus data penghar>
                                        title=""><i class="fas fa-trash"></i> </a>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>

<div class="modal fade" id="pilihCetak" tabindex="-1" aria-labelledby="pilihCetakLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pilihCetakLabel">Cetak Berdasarkan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('cetakpenghargaan')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mr-3 ml-3">
                        <select class="form-control" id="mySelect2" name="data" required>
                            <option disabled selected>--Pilih Data Yang Akan Dicetak--</option>
                            <option value="1">Seluruh Data</option>
                            <option value="2">Seluruh Data Berdasarkan Tanggal</option>
                            <option value="3">Seluruh Data yang Telah Diajukan</option>
                            <option onselect="ajutgl()" value="4">Seluruh Data yang Telah Diajukan Berdasarkan Tanggal
                            </option>
                            <option value="5">Seluruh Data yang Belum Diajukan</option>
                            <option onselect="blmajutgl()" value="6">Seluruh Data yang Belum Diajukan Berdasarkan
                                Tanggal</option>
                        </select>
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <div class="input-group" id="dari">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Dari
                                </div>
                            </div>
                            <input name="from_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <div class="input-group" id="sampai">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Sampai
                                </div>
                            </div>
                            <input name="to_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <button class="btn btn-danger" style="float:right;" type="reset"><i
                            class="fas fa-eraser"></i></button>
                    <button class="btn btn-polda mr-1" style="float:right;color: white;" type="submit"><i
                            class="fas fa-save"></i></button>

                </form>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="pilihExport" tabindex="-1" aria-labelledby="pilihExportLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pilihExportLabel">Export Berdasarkan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('exportpenghargaan')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mr-3 ml-3">
                        <select class="form-control" id="datapilih" name="data" required>
                            <option disabled selected>--Pilih Data Yang Akan Dicetak--</option>
                            <option value="1">Seluruh Data</option>
                            <option value="2">Seluruh Data Berdasarkan Tanggal</option>
                            <option value="3">Seluruh Data yang Telah Diajukan</option>
                            <option onselect="ajutgl()" value="4">Seluruh Data yang Telah Diajukan Berdasarkan Tanggal
                            </option>
                            <option value="5">Seluruh Data yang Belum Diajukan</option>
                            <option onselect="blmajutgl()" value="6">Seluruh Data yang Belum Diajukan Berdasarkan
                                Tanggal</option>
                        </select>
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <div class="input-group" id="dari2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Dari
                                </div>
                            </div>
                            <input name="from_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <div class="input-group" id="sampai2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Sampai
                                </div>
                            </div>
                            <input name="to_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <button class="btn btn-danger" style="float:right;" type="reset"><i
                            class="fas fa-eraser"></i></button>
                    <button class="btn btn-polda mr-1" style="float:right;color: white;" type="submit"><i
                            class="fas fa-save"></i></button>

                </form>
            </div>

        </div>
    </div>

    <script>
        function toggle(source) {
            checkboxes = document.getElementsByName('idsigasi[]');
            for (var i = 0, n = checkboxes.length; i < n; i++) {
                checkboxes[i].checked = source.checked;
            }
        }

    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/datapenghargaan.blade.php ENDPATH**/ ?>