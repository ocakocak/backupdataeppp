<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <br>
    
    <div class="row col-md-12">
            <div class="col-md-3" align="left">
                <a href="<?php echo e(route('cetakpersonil')); ?>" class="btn btn-polda" style="color:white;"><i
                        class="fas fa-print"></i>
                    Cetak
                </a></div>
                <div class="col-md-6" align="center">
                <h4 style="color:#6a381f;text-align:center">Data Personel</h4>
                </div>
    </div>
    
    <hr>
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card-body p-0">
        <div class="row col-md-12">
            <div class="col-md-9" align="left">
		<?php if(auth()->user()->id_aktor==3): ?>
                <a href="<?php echo e(route('tambahpersonil')); ?>" class="btn btn-polda" style="color:white;"><i
                        class="fas fa-user-plus"></i>
                    Tambah Personel
                </a></div><br><br><br>
		<?php endif; ?>
            </div>
        </div>
        <div class="card-body p-0">
            <?php echo csrf_field(); ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <tbody>
                        <tr style="width:100px">
                            <!-- <th style="width:15px">
                                    <div class="custom-checkbox custom-control">
                                        <input type="checkbox" onClick="toggle(this)">
                                    </div>
                                </th> -->
                            <th style="text-align:center">No</th>
                            <th>Nama</th>
                            <th>Pangkat</th>
                            <th>NRP/NIP</th>
                            <th>Jabatan</th>
                            <th>Kesatuan</th>
                            <th></th>
                        </tr>
                        <?php if($data_personil != null): ?>
                        <?php $__currentLoopData = $data_personil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"> <?php echo e($loop->iteration); ?> </td>
                            <td><?php echo e($pers->nama); ?></td>
                            <td><?php echo e($pers->pangkat->pangkats); ?></td>
                            <td><?php echo e($pers->nrpnip); ?></td>
                            <td><?php echo e($pers->jabatan); ?></td>
                            <td><?php echo e($pers->kesatuan->kesatuans); ?></td>
                            <td class="align-top" style="width:150px">
				<?php if(auth()->user()->id_aktor==3): ?>
                                <br><a style="color:white" href="<?php echo e(route('editpersonil', $pers->id_personil)); ?>"
                                    class="btn btn-polda style=" color:white;"btn-action mr-1" data-toggle="tooltip"
                                    title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i> </a>
                                <?php endif; ?>
				<?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==3): ?>
                                <a href="<?php echo e(route('hapuspersonil', $pers->id_personil)); ?>"
                                    class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus personel?');"  data-toggle="tooltip"
                                    title=""><i class="fas fa-trash"></i> </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="row col-md-12">


                </div><br>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script>
    function toggle(source) {
        checkboxes = document.getElementsByName('idpersonil[]');
        for (var i = 0, n = checkboxes.length; i < n; i++) {
            checkboxes[i].checked = source.checked;
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/personil/datapersonil.blade.php ENDPATH**/ ?>