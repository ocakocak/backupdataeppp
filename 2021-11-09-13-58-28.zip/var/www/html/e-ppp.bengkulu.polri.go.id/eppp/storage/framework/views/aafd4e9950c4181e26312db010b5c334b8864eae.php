<?php $__env->startSection('content'); ?>
<div class="card card-primary">
     <a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('datasatker')); ?>">
        <i class="fas fa-arrow-circle-left"></i></i> Kembali
    </a>
    <div class="card-header">
        <h4 style="color:#6a381f">Formulir Edit Satker</h4>
    </div>
    <div class="card-body p-0">
        <form action="<?php echo e(route('updatesatker', $data_satker->id_satker)); ?>" method="post" enctype="multipart/form-data">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="row">
                    <div class="col-md-12 row">
                        <div class="col-md-4 form-group">
                            <label>Nama Satker</label>
                            <input required type="text" name="satkers" value="<?php echo e($data_satker->satkers); ?>" class="form-control">
                        </div>
                        <?php if(auth()->user()->id_aktor==1): ?>
                        <div class="col-md-4 form-group">
                            <label>Kesatuan</label>
                            <div class="row ml-1" style="height:40px">
                                <select required class="select" id="id_kesatuan" name="id_kesatuan">
                                    <div>
                                        <option value="<?php echo e($data_satker->id_kesatuan); ?>"><?php echo e($data_satker->kesatuan->kesatuans); ?></option>
                                        <?php if($data_kesatuan != null): ?>
                                        <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($djs->id_kesatuan); ?>"><?php echo e($djs->kesatuans); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </select>
                            </div>
                        </div>
                        <?php else: ?>
                        <input type="hidden" value="<?php echo e($data_satker->id_kesatuan); ?>" name="id_kesatuan" class="form-control" hidden>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-polda mr-1" style="color:white" type="submit"><i class="fas fa-save"></i></button>
                <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/satker/editsatker.blade.php ENDPATH**/ ?>