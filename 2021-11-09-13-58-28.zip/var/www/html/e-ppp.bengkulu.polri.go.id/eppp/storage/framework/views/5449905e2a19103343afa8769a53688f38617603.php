<?php $__env->startSection('content'); ?>
                <div class="card card-primary">
<a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('datapersonil')); ?>">
                        <i class="fas fa-arrow-circle-left"></i></i> Kembali
                    </a>
                    <div class="card-header">
                        <h4 style="color:#6a381f;">Form Ubah Data Personel</h4>
                    </div>
                    <div class="card-body p-0">
                        <form action="<?php echo e(route('updatepersonil', $data_personil->id_personil)); ?>" method="post"
                            enctype="multipart/form-data">
                            <div class="card-body">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="row">
                                    <div class="col-md-12 row">
                                        <div class="col-md-6 form-group">
                                            <label>Nama</label>
                                            <input type="text" value="<?php echo e($data_personil->nama); ?>" name="nama"
                                                class="form-control" required>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>NRP/NIP</label>
                                            <input type="text" value="<?php echo e($data_personil->nrpnip); ?>" name="nrpnip"
                                                class="form-control"required>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Pangkat</label>
                                                <div class="row ml-1" style="height:40px">
                                                    <select class="select" id="id_pangkat" name="id_pangkat" required>
                                                        <div>
                                                            <option value="<?php echo e($data_personil->id_pangkat); ?>">
                                                                <?php echo e($data_personil->pangkat->pangkats); ?></option>
                                                            <?php if($data_pangkat != null): ?>
                                                            <?php $__currentLoopData = $data_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($djs->id_pangkat); ?>"><?php echo e($djs->pangkats); ?>

                                                            </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="id_kesatuan" value="<?php echo e($data_personil->id_kesatuan); ?>">
                                        <div class="col-md-4 form-group">
                                            <label>Jabatan</label>
                                            <input type="text" value="<?php echo e($data_personil->jabatan); ?>" name="jabatan"
                                                class="form-control"required>
                                        </div>
                                        <?php if(auth()->user()->id_aktor==1): ?>
                                        <div class="col-md-4 form-group">
                                            <label>Kesatuan</label>
                                            <div class="row ml-1" style="height:40px">
                                                <select class="select" id="id_kesatuan" name="id_kesatuan" required>
                                                    <div>
                                                        <option value="<?php echo e($data_personil->id_kesatuan); ?>">
                                                            <?php echo e($data_personil->kesatuan->kesatuans); ?></option>
                                                        <?php if($data_kesatuan != null): ?>
                                                        <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($djs->id_kesatuan); ?>"><?php echo e($djs->kesatuans); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </select>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer text-right">
                                <button class="btn btn-polda mr-1" style="color:white"type="submit"><i class="fas fa-save"></i></button>
                                <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
                            </div>
                        </form>
                    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/personil/editpersonil.blade.php ENDPATH**/ ?>