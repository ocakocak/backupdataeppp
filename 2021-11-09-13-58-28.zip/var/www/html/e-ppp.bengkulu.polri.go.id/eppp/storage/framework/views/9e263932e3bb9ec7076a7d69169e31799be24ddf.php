<!DOCTYPE html>
<html>

<head>
    <title>Rekap Data Prestasi Personel</title>
</head>

<body>
    <style type="text/css">
        body {
            font-family: serif;
            font-size: 12px;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        table th,
        table td {
            position: relative;
            border: 1px solid #3c3c3c;
            padding: 3px 8px;
            text-align: top;
        }

        a {
            background: blue;
            color: #fff;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
        }

    </style>

    <?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Rekap Data Prestasi Personel.xls");
	?>

    <center>
        <h1>Rekap Data Prestasi Personel</h1>
    </center>

    <table border="1">
        <tr>
            <th style="width:5px">
                No
            </th>
            <th style="width:50px">Tanggal Input</th>
            <th style="width:150px">Nama</th>
            <th style="width:150px">Pangkat</th>
            <th style="width:150px">NRP/NIP</th>
            <th style="width:150px">Jabatan</th>
            <th style="width:150px">Kesatuan</th>
            <th style="width:200px">Uraian Prestasi</th>
            <th style="width:100px">Keterangan</th>
        </tr>
        <?php if($data_sigasi != null): ?>
        <?php $__currentLoopData = $data_sigasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($dg->nama_prestasi != null): ?>
        <tr style="width:1000px">
            <td style="width:30px" valign="top">
                <p><?php echo e($loop->iteration); ?></p>
            </td>
            <td style="width:50px;text-align:justify" valign="top"><?php echo e(date('d-m-Y', strtotime($dg->tanggal_input))); ?> </td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->nama); ?> </td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->pangkat->pangkats); ?></td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->nrpnip); ?></td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->jabatan); ?></td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->kesatuan->kesatuans); ?>

            </td>
            <td style="width:200px;text-align:justify" valign="top"><?php echo e($dg->nama_prestasi); ?></td>
            <td style="width:100px;text-align:justify" valign="top">
                <?php if($dg->keterangan == 0): ?>
                    Belum Ditindak Lanjuti
                <?php elseif($dg->keterangan == 1): ?>
			<?php if($dg->personil->id_kesatuan == 11): ?>
                            No Surat : <?php echo e($dg->no_file_bukti_surat); ?> <br> Sedang di Tindak Lanjut POLDA
                        <?php else: ?>
                            No Surat : <?php echo e($dg->no_file_bukti_surat); ?>  Sedang di Tindak Lanjut POLRES
                        <?php endif; ?>
                <?php elseif($dg->keterangan == 2): ?>
                    Sudah Ditindak Lanjuti ke POLDA
                <?php elseif($dg->keterangan == 3): ?>
                        Pengajuan Diterima
		<?php endif; ?>
            </td>
            <!-- <td >
                                <?php if($dg->status_tindakan=='Belum Ditindak'): ?>
                                <br><a style="color:white"href="<?php echo e(route('tindaksigasi', $dg->id_sigasi)); ?>"class="btn btn-polda style="color:white btn-action mr-1" data-toggle="tooltip" title="" >Tindak Sekarang</a>  
                                <?php else: ?>
                                <br><a href="<?php echo e(route('tindaksigasi', $dg->id_sigasi)); ?>"class="btn btn-danger btn-action mr-1" data-toggle="tooltip" title="" data-original-title="Edit">Batal Tindak</a>  
                                <?php endif; ?>
                            </td> -->
        </tr>
	<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
</body>

</html>
<?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/exportprestasi.blade.php ENDPATH**/ ?>