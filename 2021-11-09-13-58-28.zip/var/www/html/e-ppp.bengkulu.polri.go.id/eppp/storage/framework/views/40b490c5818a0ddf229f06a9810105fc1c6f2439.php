<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
<a href="http://e-ppp.bengkulu.polri.go.id/">
    <img style="margin-top: 15px;"src="<?php echo e(asset('logoeppp.png')); ?>" alt="logo" width="120" >
</a>
</div>
    <ul class="sidebar-menu">
        <br>
        <br>
        <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==2||auth()->user()->id_aktor==3): ?>
        <li class="menu-header" style="color:black;font-weight:bold"><span>Halaman Utama</span></li>
        <li><a class="nav-link mb-1" style="background-color:#00001A;color:white" href="<?php echo e(route('dashboardadmin')); ?>"><i class="fas fa-tachometer-alt"></i><span style="font-size:10pt">Halaman Utama</span></a>
        <li><a class="nav-link mb-1" style="background-color:#000033;color:white"href="<?php echo e(route('jenissyarat')); ?>"><i class="fas fa-users"></i><span style="font-size:10pt">Jenis dan Syarat Penghargaan</span></a>
        <li class="menu-header" style="color:black;font-weight:bold">Pengolahan Data</li>
        <?php endif; ?>
        <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==2): ?>
        <li><a class="nav-link mb-1" style="background-color:#001A4D;color:white"href="<?php echo e(route('datasatker')); ?>"><i class="fas fa-users"></i><span style="font-size:10pt">Data Satker</span></a>
	<?php endif; ?>
	<?php if(auth()->user()->id_aktor==1): ?>
	<li><a class="nav-link mb-1" style="background-color:#001A4D;color:white"href="<?php echo e(route('dataadmin')); ?>"><i class="fas fa-users"></i><span style="font-size:10pt">Data Admin</span></a>
        <?php endif; ?>
        <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==2): ?>
        <li><a class="nav-link mb-1" style="background-color:#001A4D;color:white"href="<?php echo e(route('datapengguna')); ?>"><i class="fas fa-users"></i><span style="font-size:10pt">User</span></a>
        <?php endif; ?>
        <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==3): ?>
        <li><a class="nav-link mb-1" style="background-color:#003366;color:white"href="<?php echo e(route('datapersonil')); ?>"><i class="fas fa-user-alt"></i><span style="font-size:10pt">Data Personel</span></a>
        <?php endif; ?>
	<?php if(auth()->user()->id_aktor==3): ?>
	<li><a class="nav-link mb-1" style="background-color:#004D80;color:white"href="<?php echo e(route('tambahsigasi')); ?>"><i class="fas fa-file-medical"></i><span style="font-size:10pt">Tambah Data</span></a>
      	<?php endif; ?>
        <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==2||auth()->user()->id_aktor==3): ?>
        <li><a class="nav-link mb-1" style="background-color:#006699;color:white"href="<?php echo e(route('datasigasiprestasi')); ?>"><i class="fas fa-medal"></i><span style="font-size:10pt">Data Prestasi</span></a>
        <li><a class="nav-link mb-1"style="background-color:#0080B3;color:white" href="<?php echo e(route('datasigasipenghargaan')); ?>"><i class="fas fa-trophy"></i><span style="font-size:10pt">Data Penghargaan</span></a>
        <?php endif; ?>
        <?php if(auth()->user()->id_aktor==4): ?>
        <li class="menu-header" style="color:black;font-weight:bold"><span>Halaman Utama</span></li>
        <li><a class="nav-link" style="background-color:black;color:white" href="<?php echo e(route('depan')); ?>"><i class="fas fa-tachometer-alt"></i><span style="font-size:10pt">Halaman Utama</span></a>
        <li class="menu-header" style="color:black;font-weight:bold">Pengolahan Data</li>
        <li><a class="nav-link" style="background-color:#006699;color:white"href="<?php echo e(route('info')); ?>"><i class="fas fa-info-circle"></i><span>Informasi</span></a>
        <li><a class="nav-link" style="background-color:#0080B3;color:white"href="<?php echo e(route('berita')); ?>"><i class="far fa-newspaper"></i><span>Berita</span></a>
        <?php endif; ?>
    </ul>
</aside>
<?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/templateadmin/sidebar.blade.php ENDPATH**/ ?>