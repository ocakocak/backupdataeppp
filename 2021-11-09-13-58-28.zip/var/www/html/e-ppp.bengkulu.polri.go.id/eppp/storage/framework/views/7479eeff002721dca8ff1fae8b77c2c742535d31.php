<?php $__env->startSection('content'); ?>
<div class="row col-md-12">
    <div class="col-md-3">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('filterprestasi')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <h6 style="color:#6a381f;">Cari Berdasarkan</h6><br>
                    <?php if(auth()->user()->id_aktor == 1): ?>
                    <div class="form-group">
                        <label>Pilih Kesatuan</label>
                        <select class="form-control" name="id_kesatuan">
                            <option></option>
                            <?php if($data_kesatuan != null): ?>
                            <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dk->id_kesatuan); ?>"><?php echo e($dk->kesatuans); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
		    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
			    <?php $data_satker = App\Models\Satker::all(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
		    <?php elseif(auth()->user()->id_aktor == 2 && auth()->user()->id_kesatuan == 11): ?>
        	    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
                            <?php $data_satker = App\Models\Satker::where('id_kesatuan',11)->get(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <?php elseif(auth()->user()->id_aktor == 2 && auth()->user()->id_kesatuan != 11): ?>
                    <div class="form-group">
                        <label>Pilih Sakter/Satwil</label>
                        <select class="form-control" name="id_satker">
                            <option></option>
                            <?php $data_satker = App\Models\Satker::where('id_kesatuan',auth()->user()->id_kesatuan)->get(); ?>
                            <?php if($data_satker != null): ?>
                            <?php $__currentLoopData = $data_satker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dsk->id_satker); ?>"><?php echo e($dsk->satkers); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label>Pilih Pangkat</label>
                        <select class="form-control" name="id_pangkat">
                            <option></option>
                            <?php if($data_pangkat != null): ?>
                            <?php $__currentLoopData = $data_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dp->id_pangkat); ?>"><?php echo e($dp->pangkats); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="input-group" id="dari2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Dari
                                </div>
                            </div>
                            <input name="from_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group" id="sampai2">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    Sampai
                                </div>
                            </div>
                            <input name="to_date" type="date" class="form-control daterange-cus">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Nama</label>
                        <div class="input-group">
                            <input type="text" class="form-control daterange-cus" name="namapersonil">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>NRP/NIP</label>
                        <div class="input-group">
                            <input type="text" class="form-control daterange-cus" name="nrpnip">
                        </div>
                    </div>
                    <?php if(auth()->user()->id_aktor == 1 || auth()->user()->id_aktor == 2): ?>
                    <div class="form-group">
                        <select class="form-control" id="datapilih" name="data" required>
                            <option disabled selected>Pilih Data</option>
                            <option value="1">Seluruh Data</option>
                            <option value="2">Data yang Telah Diajukan Tingkat POLDA</option>
                        </select>
                    </div>
                    <?php endif; ?>
                    <br>
                    <div class="col-md-12">
                    <button value="submit3" type="submit" name="submit" class="btn btn-polda col-md-12"
                        style="color:white;float:left"><i class="fas fa-search"></i> Cari</button>
                    </div>
                    <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==2): ?>
                    <br>
                    <br>
                    <div class="col-md-12">
                    <button value="submit1" type="submit" name="submit" class="btn btn-success col-md-12"
                        style="color:white;float:left"><i class="far fa-file-excel"></i> Excel</button>
                    </div>
                    <br>
                    <br>
                    <div class="col-md-12">
                    <button value="submit2" type="submit" name="submit" class="btn btn-polda col-md-12"
                        style="color:white;float:left"><i class="fas fa-print"></i> Cetak</button>
                    </div>
                    <?php endif; ?>
                    </div>
            </form>
        </div>
    </div>
    <div class="col-md-9 card card-primary">
        <div class="card-body p-0">
            <div class="row col-md-12">
<div class="mt-3 col-md-12">
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
                <div class="col-md-12" align="center">
                    <h4 style="color:#6a381f;text-align:center"><br>Data Prestasi Personel</h4>
                </div>
            </div>
            <hr>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                            <tr style="width:1000px">
                                <th style="width:5px">
                                    No
                                </th>
                                <th style="width:50px">Tanggal Input</th>
                                <th style="width:150px">Nama</th>
                                <th style="width:150px">Pangkat</th>
                                <th style="width:150px">NRP/NIP</th>
                                <th style="width:150px">Jabatan</th>
                                <th style="width:150px">Kesatuan</th>
                                <th style="width:200px">Uraian Prestasi</th>
                                <th style="width:100px">Uraian Kronologis Prestasi</th>
                                <th style="width:100px">Evidence</th>
                                <th style="width:100px">
                                    <?php if(auth()->user()->id_aktor==1): ?>
                                    Verifikasi
                                    <?php else: ?>
                                    Keterangan
                                    <?php endif; ?>
                                </th>
                                <?php if(auth()->user()->id_aktor==1): ?>
                                <th style="width:100px">
                                    Keterangan
                                </th>
                                <?php elseif(auth()->user()->id_aktor==3): ?>
                                <th style="width:100px">
                                    Edit Data
                                </th>
                                <?php endif; ?>
                                <th>
                                </th>
                                <th>
                                </th>
                            </tr>
			    <?php $no = 1; ?>
                            <?php if($data_sigasi != null): ?>
                            <?php $__currentLoopData = $data_sigasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <?php if($dg->nama_prestasi != null): ?>
                            <tr style="width:5px">
                                <td class="align-top" style="width:5px"><br><?php echo e($no++); ?>

                                </td>
                                <td style="width:50px" class="align-top text-justify"><br>
                                    <?php echo e(date('d-m-Y', strtotime($dg->tanggal_input))); ?> </td>
                                <td style="width:150px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->nama); ?> </td>
                                <td style="width:150px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->pangkat->pangkats); ?></td>
                                <td style="width:150px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->nrpnip); ?></td>
                                <td style="width:150px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->jabatan); ?>

                                </td>
                                <td style="width:150px" class="align-top text-justify"><br>
                                    <?php echo e($dg->personil->kesatuan->kesatuans); ?>

                                </td>
                                <td style="width:100px" class="align-top text-justify" style="font-weight:bold">
                                    <br><?php echo e($dg->nama_prestasi); ?></td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php if(auth()->user()->id_aktor==3): ?>
                                    <button data-toggle="modal" data-target="#lihaturaian<?php echo e($dg->id_sigasi); ?>"
                                            style="color: white;" class="btn btn-polda">
                                            <i class="far fa-eye"></i></button>
                                        <div class="modal fade" width="60" id="lihaturaian<?php echo e($dg->id_sigasi); ?>"
                                            tabindex="-1" aria-labelledby="lihaturaian<?php echo e($dg->id_sigasi); ?>Label"
                                            aria-hidden="true">
                                            <div class="modal-dialog mx-auto">
                                                <!-- <div class="card mx-auto pt-3 pl-3" style="width: 40rem;"> -->
                                                <div class="modal-content mx-auto">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="lihaturaian<?php echo e($dg->id_sigasi); ?>Label">
                                                            Uraian Kronologis Prestasi</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
							<form action="<?php echo e(route('updatekronologis',$dg->id_sigasi)); ?>" method="post" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<?php echo method_field('patch'); ?>
                                                            <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                                class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">Nama Prestasi</label>
                                                                <input type="text" class="form-control" readonly
                                                                    value="<?php echo e($dg->nama_prestasi); ?>">
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">Uraian Kronologis Prestasi</label>
                                                                <input type="text" class="form-control" readonly
                                                                    value="<?php echo e($dg->deskripsi); ?>">
                                                            </div>
								<hr>
								<div class="form-group row mr-3 ml-3">
                                                                	<label style="font-size: 15px;">Ubah Kronologis</label>
                                                                	<input type="file" class="form-control" name="deskripsi" required>
									<small>Upload file sesuai ketentuan</small>
</div>
									<button class="btn-user btn btn-action btn-polda float-right" style="color:white" 
type="submit">Ubah file</button>
							</form>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <?php elseif(auth()->user()->id_aktor==1): ?>
                                    <button data-toggle="modal" data-target="#lihaturaian<?php echo e($dg->id_sigasi); ?>"
                                            style="color: white;" class="btn btn-polda">
                                            <i class="far fa-eye"></i></button>
                                        <div class="modal fade" width="60" id="lihaturaian<?php echo e($dg->id_sigasi); ?>"
                                            tabindex="-1" aria-labelledby="lihaturaian<?php echo e($dg->id_sigasi); ?>Label"
                                            aria-hidden="true">
                                            <div class="modal-dialog mx-auto">
                                                <!-- <div class="card mx-auto pt-3 pl-3" style="width: 40rem;"> -->
                                                <div class="modal-content mx-auto">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="lihaturaian<?php echo e($dg->id_sigasi); ?>Label">
                                                            Uraian Kronologis Prestasi</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('updatekronologis',$dg->id_sigasi)); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('patch'); ?>
                                                            <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                                class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">Nama Prestasi</label>
                                                                <input type="text" class="form-control" readonly
                                                                    value="<?php echo e($dg->nama_prestasi); ?>">
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3">
								<label style="font-size: 15px;">File Uraian Kronologis</label>
                                                            </div>
							    <div class="form-group row mr-3 ml-3">
                                                                
								<a href="<?php echo e(route('lihaturaiankronologis', $dg->id_sigasi)); ?>"><?php echo e($dg->deskripsi); ?> </a>
                                                            	
							    </div>

                                                                <hr>
                                                                <div class="form-group row mr-3 ml-3">
                                                                        <label style="font-size: 15px;">Ubah Kronologis</label>
                                                                        <input type="file" class="form-control" name="deskripsi" required>
                                                                        <small>Upload file sesuai ketentuan</small>
								</div>
								<button class="btn-user btn btn-action btn-polda float-right" style="color:white" 
								type="submit">Ubah file</button>
                                                        </form>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

					<?php else: ?>
                                    <a href="<?php echo e(route('lihaturaiankronologis', $dg->id_sigasi)); ?>"
                                        class="btn btn-polda btn-action trigger--fire-modal-1" data-toggle="tooltip"
                                        title=""><i class="far fa-eye"></i> </a>
                                    <?php endif; ?>
                                </td>
                                <td style="width:100px" class="align-top " style="font-weight:bold"><br>
                                    <center>
                                        <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==2||
                                        auth()->user()->id_aktor==3): ?>
                                        <button data-toggle="modal" data-target="#tambahBukti<?php echo e($dg->id_sigasi); ?>"
                                            style="color: white;" class="btn btn-polda">
                                            <i class="far fa-eye"></i></button>

                                        <div class="modal fade" id="tambahBukti<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                            aria-labelledby="tambahBukti<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="tambahBukti<?php echo e($dg->id_sigasi); ?>Label">
                                                            Tambah Bukti
                                                            Prestasi</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('tambahbuktiprestasi')); ?>" method="post"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                                class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">Nama Prestasi</label>
                                                                <input type="text" class="form-control" readonly
                                                                    value="<?php echo e($dg->nama_prestasi); ?>">
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3">
                                                                <label style="font-size: 15px;">File Bukti</label>
                                                                <?php $databukti=App\Models\BuktiPrestasi::where('id_sigasi',$dg->id_sigasi)->get(); ?>
                                                                <?php $__currentLoopData = $databukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->id_aktor==1||auth()->user()->id_aktor==2): ?>
                                                                <div class="col-sm-11">
								<a href="<?php echo e(route('lihatbuktisigasi', $databukti->id_bukti_prestasi)); ?>"><?php echo e($databukti->file_bukti_prestasi); ?></a>
                                                                </div>
								<div class="col-sm-1">
                                                                 
								<a onclick="return confirm('Apakah Anda yakin ingin menghapus bukti?')" href="<?php echo e(route('hapusbuktiprestasi', $databukti->id_bukti_prestasi)); ?>">
                                                                        <i class="fas fa-trash-alt"></i>
                                                                </a>
								</div>
                                                                <?php else: ?>
                                                                <div class="col-sm-11">
                                                                <?php echo e($databukti->file_bukti_prestasi); ?>

                                                            </div>
								<a onclick="return confirm('Apakah Anda yakin ingin menghapus bukti?')" href="<?php echo e(route('hapusbuktiprestasi', $databukti->id_bukti_prestasi)); ?>">
									<i class="fas fa-trash-alt"></i>
								</a>
								<?php endif; ?>
                                                                <hr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3">

                                                                <label style="font-size: 15px;">Tambah File Bukti
                                                                    Prestasi</label>
                                                                <input name="file_bukti_prestasi[]" type="file"
                                                                    class="form-control" multiple="true" required>
                                                            </div>
                                                            <div class="form-group row mr-3 ml-3 float-right">
                                                                <button class="btn btn-polda mr-1" style="color: white;"
                                                                    type="submit">Tambah File</button>
                                                            </div>
                                                        </form>
                                                    </div>

                                                </div>
                                            </div>
                                            <?php endif; ?>
                                    </center>
                                </td>
                                <td style="width:100px" class="align-top text-justify"><br>
                                    <?php $validasi = App\Models\Validasi::where('id_sigasi',$dg->id_sigasi)->where('status',2)->latest()->first(); ?>
                                    <?php if($dg->keterangan == "0"): ?>
                                    <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==2): ?>
                                    <?php if($validasi == null): ?>
                                    Belum Diajukan
                                    <?php else: ?>
                                    Pengajuan Telah Ditolak dengan Catatan : <?php echo e($validasi->catatan_validasi); ?>

                                    <?php endif; ?>
                                    <?php elseif(auth()->user()->id_aktor==3): ?>
                                    <?php if($validasi == null): ?>

                                    <button data-toggle="modal" data-target="#modalsurat1<?php echo e($dg->id_sigasi); ?>" style="color: white;"
                                        class="btn btn-polda"><?php if(auth()->user()->id_kesatuan==11): ?>
                                        Tindak Lanjut ke POLDA
                                        <?php else: ?>
                                        Tindak Lanjut ke POLRES
                                        <?php endif; ?></button>
                                    <div class="modal fade" id="modalsurat1<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalsurat1<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalsurat1<?php echo e($dg->id_sigasi); ?>Label">
                                                        Surat Permohonan</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('tindaklanjutsigasi',$dg->id_sigasi)); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">

                                                        <div class="form-group">
                                                            <label>No Surat Permohonan</label>
                                                            <input type="text" name="no_file_bukti_surat"
                                                                class="form-control" required>
                                                        </div>
                                                        <div class="form-group">
                                                        <label>Jenis Surat Permohonan</label>
                                                                <select class="form-control" id="jenis_surat"
                                                                    name="jenis_surat" required>
                                                                    <option value="" style="color: grey;" disabled
                                                                        selected>-Pilih Jenis Surat Permohonan-</option>
                                                                    <option value="KPLB">KPLB
                                                                    </option>
                                                                    <option value="KPLBA">KPLBA</option>
                                                                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                                                                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                                                                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                                                                </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unggah Surat Permohonan</label>
                                                            <input type="file" name="file_bukti_surat"
                                                                class="form-control" required>
                                                        </div>
                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Simpan</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <?php else: ?>
 
                                    Pengajuan Telah Ditolak dengan Catatan : <?php echo e($validasi->catatan_validasi); ?><br><br>
                                    <button data-toggle="modal" data-target="#modalsurat2<?php echo e($dg->id_sigasi); ?>"
                                        style="color: white;" class="btn btn-polda">
                                        Tindak Lanjut ke POLRES</button>
                                    <div class="modal fade" id="modalsurat2<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalsurat2<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalsurat2<?php echo e($dg->id_sigasi); ?>Label">
                                                        Surat Permohonan ke
                                                        POLRES</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('tindaklanjutsigasi',$dg->id_sigasi)); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                        <div class="form-group">
                                                            <label>No Surat Permohonan</label>
                                                            <input type="text" name="no_file_bukti_surat"
                                                                class="form-control" required>
                                                        </div>
                                                        <div class="form-group">
                                                        <label>Jenis Surat Permohonan</label>
                                                                <select class="form-control" id="jenis_surat"
                                                                    name="jenis_surat" required>
                                                                    <option value="" style="color: grey;" disabled
                                                                        selected>-Pilih Jenis Surat Permohonan-</option>
                                                                    <option value="KPLB">KPLB
                                                                    </option>
                                                                    <option value="KPLBA">KPLBA</option>
                                                                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                                                                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                                                                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                                                                </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unggah Surat Permohonan</label>
                                                            <input type="file" name="file_bukti_surat"
                                                                class="form-control" required>
                                                        </div>
                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Simpan</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php elseif($dg->keterangan == "1"): ?>
                                    <?php if(auth()->user()->id_aktor==1 || auth()->user()->id_aktor==3 ): ?>
                                    <?php if($dg->personil->id_kesatuan == 11): ?>
                                    No Surat : <?php echo e($dg->no_file_bukti_surat); ?> <br> Sedang di Tindak Lanjut POLDA
                                    <?php else: ?>
                                    No Surat : <?php echo e($dg->no_file_bukti_surat); ?>  Sedang di Tindak Lanjut POLRES
                                    <?php endif; ?>
                                    <?php elseif(auth()->user()->id_aktor==2): ?>
                                    <?php if(auth()->user()->id_kesatuan == 11): ?>
                                    <button data-toggle="modal" data-target="#modalvalidasi<?php echo e($dg->id_sigasi); ?>"
                                        style="color: white;" class="btn btn-polda">
                                        Verifikasi</button>
                                    <div class="modal fade" id="modalvalidasi<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalvalidasi<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalvalidasi<?php echo e($dg->id_sigasi); ?>Label">
                                                        Verifikasi</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('tindaklanjutsigasi',$dg->id_sigasi)); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                        <div class="form-group">
                                                            <label>Uraian Prestasi</label>
                                                            <input type="text" name="nama_prestasi"
                                                                value="<?php echo e($dg->nama_prestasi); ?>" class="form-control"
                                                                readonly>
                                                        </div>

                                                        <div class="form-group row mr-3 ml-3">
                                                            <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                            <label style="font-size: 15px;">File Bukti Surat Permohonan
                                                                ke POLRES</label>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisurat', $dg->id_sigasi)); ?>"><?php echo e($dg->file_bukti_surat); ?></a>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>
                                                            <hr>
                                                            <?php endif; ?>
                                                        </div>

                                                        <div class="form-group row mr-3 ml-3">
                                                            <label style="font-size: 15px;">File Bukti Surat Permohonan
                                                                ke POLDA</label>
                                                            <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisuratadmin', $dg->id_sigasi)); ?>"><?php echo e($dg->suratadmin); ?></a>
                                                            <?php else: ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisurat', $dg->id_sigasi)); ?>"><?php echo e($dg->file_bukti_surat); ?></a>
                                                            <?php endif; ?>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>

                                                            <hr>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Pengajuan</label>
                                                            <select class="form-control" id="SelectPengajuan"
                                                                name="status" required>
                                                                <option value="" style="color: grey;" disabled selected>
                                                                    -Pilih-</option>
                                                                <option onselect="valid()" value="1">Diterima</option>
                                                                <option onselect="invalid()" value="2">Ditolak</option>
                                                            </select>
                                                        </div>
                                                        <div id="catatan_validasi">
                                                            <div class="form-group">
                                                                <label>Catatan</label>
                                                                <input type="text" name="catatan_validasi"
                                                                    class="form-control">
                                                            </div>
                                                        </div>
                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Simpan</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <?php else: ?>
   
                                    <button data-toggle="modal" data-target="#modalsurat3<?php echo e($dg->id_sigasi); ?>"
                                        style="color: white;" class="btn btn-polda">
                                        Tindak Lanjut ke POLDA</button>
                                    <div class="modal fade" id="modalsurat3<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalsurat3<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalsurat3<?php echo e($dg->id_sigasi); ?>Label">
                                                        Surat Permohonan POLDA
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('tindaklanjutsigasi',$dg->id_sigasi)); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        
							<div class="form-group">
                                                            <label>Uraian Prestasi</label>
                                                            <input type="text" name="nama_prestasi"
                                                                value="<?php echo e($dg->nama_prestasi); ?>" class="form-control"
                                                                readonly>
                                                        </div>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                        <div class="form-group row mr-3 ml-3">
                                                            <label style="font-size: 15px;">File Bukti Surat Permohonan
                                                            <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                                ke POLRES
                                                            <?php else: ?>
                                                                ke POLDA
                                                            <?php endif; ?>
                                                                </label>
                                                                
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisurat', $dg->id_sigasi)); ?>"><?php echo e($dg->file_bukti_surat); ?></a>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>
                                                            
                                                            <hr>
                                                        </div>
							<div class="form-group">
							<label>Pengajuan</label>
                                                        <select class="form-control" id="SelectPengajuan"
                                                              name="status" required>
                                                                <option value="" style="color: grey;" disabled selected>
                                                          -Pilih-</option>
                                                         <option onselect="valid()" value="1">Diterima</option>
                                                           <option onselect="invalid()" value="2">Ditolak</option>
                                                         </select>
                                                         </div>
                                                        <div id="suratpermohonanpoldaadmin">
                                                        <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                        <div class="form-group">
                                                            <label>No Surat Permohonan ke POLDA</label>
                                                            <input type="text" name="nosuratadmin" class="form-control">
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Jenis Surat Permohonan</label>
                                                            <select class="form-control"
                                                                    name="jenissuratadmin">
                                                                    <option value="" style="color: grey;" disabled
                                                                        selected>-Pilih Jenis Surat Permohonan-</option>
                                                                    <option value="KPLB">KPLB
                                                                    </option>
                                                                    <option value="KPLBA">KPLBA</option>
                                                                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                                                                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                                                                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                                                                </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unggah Surat Permohonan ke POLDA</label>
                                                            <input type="file" name="suratadmin" class="form-control">
                                                        </div>
                                                        <?php endif; ?>
							</div>					
                                                        <div id="catatan_validasi">
                                                            <div class="form-group">
                                                                <label>Catatan</label>
                                                                <input type="text" name="catatan_validasi"
                                                                    class="form-control">
                                                            </div>
                                                        </div>

                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Tindak Lanjut</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php elseif($dg->keterangan == "2"): ?>
                                    <?php if(auth()->user()->id_aktor==1): ?>
   
                                    <button data-toggle="modal" data-target="#modalvalidasi<?php echo e($dg->id_sigasi); ?>"
                                        style="color: white;" class="btn btn-polda">
                                        Verifikasi</button>
                                    <div class="modal fade" id="modalvalidasi<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalvalidasi<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalvalidasi<?php echo e($dg->id_sigasi); ?>Label">
                                                        Verifikasi</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('validasiprestasi',$dg->id_sigasi)); ?>"
                                                        method="get" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                        <div class="form-group">
                                                            <label>Uraian Prestasi</label>
                                                            <input type="text" name="nama_prestasi"
                                                                value="<?php echo e($dg->nama_prestasi); ?>" class="form-control"
                                                                readonly>
                                                        </div>

                                                        <div class="form-group row mr-3 ml-3">
                                                            <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                            <label style="font-size: 15px;">File Bukti Surat Permohonan
                                                                ke POLRES</label>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisurat', $dg->id_sigasi)); ?>"><?php echo e($dg->file_bukti_surat); ?></a>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>
                                                            <hr>
                                                            <?php endif; ?>
                                                        </div>

                                                        <div class="form-group row mr-3 ml-3">
                                                            <label style="font-size: 15px;">File Bukti Surat Permohonan
                                                                ke POLDA</label>
                                                            <?php if($dg->personil->id_kesatuan ==
                                                            1||$dg->personil->id_kesatuan ==
                                                            2||$dg->personil->id_kesatuan == 3||
                                                            $dg->personil->id_kesatuan == 4||$dg->personil->id_kesatuan
                                                            == 5||$dg->personil->id_kesatuan == 6||
                                                            $dg->personil->id_kesatuan == 7||$dg->personil->id_kesatuan
                                                            == 8||$dg->personil->id_kesatuan ==
                                                            9||$dg->personil->id_kesatuan == 10): ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisuratadmin', $dg->id_sigasi)); ?>"><?php echo e($dg->suratadmin); ?></a>
                                                            <?php else: ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisurat', $dg->id_sigasi)); ?>"><?php echo e($dg->file_bukti_surat); ?></a>
                                                            <?php endif; ?>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>

                                                            <hr>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                                <label>Permohonan di Unggah Oleh : </label>
                                                                <input type="text" name="id_user" value="<?php echo e($dg->user->username); ?>"
                                                                    class="form-control" readonly>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label>Pengajuan</label>
                                                            <select class="form-control" id="SelectPengajuan2"
                                                                name="status">
                                                                <option value="" style="color: grey;" disabled selected>
                                                                    -Pilih-</option>
                                                                <option onselect="valid()" value="1">Diterima</option>
                                                                <option onselect="invalid()" value="2">Ditolak</option>
                                                            </select>
                                                        </div>
                                                        <div id="catatan_validasi2">
                                                            <div class="form-group">
                                                                <label>Catatan</label>
                                                                <input type="text" name="catatan_validasi"
                                                                    class="form-control">
                                                            </div>
                                                        </div>
                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Simpan</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                    <?php elseif(auth()->user()->id_aktor==2): ?>
	               			<?php if($dg->personil->id_kesatuan == 11): ?>
                                    No Surat : <?php echo e($dg->no_file_bukti_surat); ?> <br> Sedang di Verifikasi POLDA
                                    <?php else: ?>
                                    No Surat : <?php echo e($dg->nosuratadmin); ?> <br> Sedang di Verifikasi POLDA
                                    <?php endif; ?>

                                    <?php elseif(auth()->user()->id_aktor==3): ?>
                                    <?php if($dg->personil->id_kesatuan == 11): ?>
                                    No Surat : <?php echo e($dg->no_file_bukti_surat); ?> <br> Sedang di Verifikasi POLDA
                                    <?php else: ?>
                                    No Surat : <?php echo e($dg->nosuratadmin); ?> <br> Sedang di Verifikasi POLDA
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php elseif($dg->keterangan==3): ?>
                                    <?php if($dg->personil->id_kesatuan == 11): ?>
                                    No Surat : <?php echo e($dg->no_file_bukti_surat); ?>

                                    <?php else: ?>
                                    No Surat : <?php echo e($dg->nosuratadmin); ?>

                                    <?php endif; ?>
                                    <br>
                                    Pengajuan di Terima
                                    <?php endif; ?>
                                    <br><br>
                                </td>
                                <td class="align-top">
                                    <br>
                                    <?php if(auth()->user()->id_aktor==1): ?>
                                    <?php if($dg->nama_penghargaan == null): ?>
                  
                                   <button data-toggle="modal" data-target="#modalberipenghargaan<?php echo e($dg->id_sigasi); ?>"
                                       style="color: white;" class="btn btn-polda"> 
                                       Upload Kep Penghargaan</button>
                                    <div class="modal fade" id="modalberipenghargaan<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalberipenghargaanLabel<?php echo e($dg->id_sigasi); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalberipenghargaanLabel<?php echo e($dg->id_sigasi); ?>">Upload Kep
                                                        Penghargaan
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('beripenghargaan',$dg->id_sigasi)); ?>"
                                                        method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('patch'); ?>
                                                        <input name="id_sigasi" id="id_sigasi" type="hidden"
                                                            class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
                                                        <div class="form-group">
                                                            <label>Uraian Prestasi</label>
                                                            <input type="text" name="nama_prestasi"
                                                                value="<?php echo e($dg->nama_prestasi); ?>" class="form-control"
                                                                readonly>
                                                        </div>
                                                        <div class="form-group row mr-3 ml-3">
                                                            <label style="font-size: 15px;">File Bukti Prestasi</label>
                                                            <?php $databukti=App\Models\BuktiPrestasi::where('id_sigasi',$dg->id_sigasi)->get(); ?>
                                                            <?php $__currentLoopData = $databukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisigasi', $databukti->id_bukti_prestasi)); ?>"><?php echo e($databukti->file_bukti_prestasi); ?></a>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>
                                                            <hr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                        <hr style="background-color:red">
                                                        <div class="form-group">
                                                            <label>Nama Penghargaan</label>
                                                            <input type="text" name="nama_penghargaan"
                                                                class="form-control" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Keterangan Penghargaan</label>
                                                            <input type="text" name="keterangan_penghargaan"
                                                                class="form-control"required>
                                                        </div>
                                                        <div class="form-group">
                                                                <label>Jenis Penghargaan</label>
                                                                <select class="form-control" name="jenis_penghargaan" required>
                                                                    <option value="" style="color: grey;" disabled
                                                                        selected>-Pilih Jenis Penghargaan-</option>
                                                                    <option value="KPLB">KPLB
                                                                    </option>
                                                                    <option value="KPLBA">KPLBA</option>
                                                                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                                                                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                                                                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                                                                </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Pemberi Penghargaan</label>
                                                            <input type="text" name="sumber" class="form-control" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Unggah file bukti</label>
                                                            <input name="file_bukti_penghargaan[]" type="file"
                                                                class="form-control" multiple="true">
                                                        </div>
                                                        <button type="submit" class="btn btn-polda"
                                                            style="float:right;color:white">Simpan</button>
                                                </div>
                                                </form>
                                            </div>

                                        </div>

                                    </div>
                                    <?php else: ?>
                                    Telah Menerima Penghargaan<br>
          
                                    <button data-toggle="modal" data-target="#modalberipenghargaan<?php echo e($dg->id_sigasi); ?>"
                                        style="color: white;" class="btn btn-polda">
                                        <i class="far fa-eye"></i></button>
                                    <div class="modal fade" id="modalberipenghargaan<?php echo e($dg->id_sigasi); ?>" tabindex="-1"
                                        aria-labelledby="modalberipenghargaan<?php echo e($dg->id_sigasi); ?>Label" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="modalberipenghargaan<?php echo e($dg->id_sigasi); ?>Label">Data Penghargaan
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Nama Penghargaan</label>
                                                            <input type="text" name="nama_penghargaan"
                                                                class="form-control"value="<?php echo e($dg->nama_penghargaan); ?>" readonly>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Keterangan Penghargaan</label>
                                                            <input type="text" name="keterangan_penghargaan"
                                                                class="form-control"value="<?php echo e($dg->keterangan_penghargaan); ?>" readonly>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Jenis Penghargaan</label>
                                                            <input type="text" name="jenis_penghargaan"
                                                                class="form-control"value="<?php echo e($dg->jenis_penghargaan); ?>" readonly>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Pemberi Penghargaan</label>
                                                            <input type="text" name="sumber" class="form-control"value="<?php echo e($dg->sumber); ?>" readonly>
                                                        </div>
                                                        <div class="form-group row mr-3 ml-3">
                                                            <label style="font-size: 15px;">File Bukti</label>
                                                            <?php $databukti=App\Models\BuktiPenghargaan::where('id_sigasi',$dg->id_sigasi)->get(); ?>
                                                            <?php $__currentLoopData = $databukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a class="col-sm-11"
                                                                href="<?php echo e(route('lihatbuktisigasi2', $databukti->id_bukti_penghargaan)); ?>"><?php echo e($databukti->file_bukti_penghargaan); ?></a>
                                                            <div class="col-sm-1">
                                                                <i class="fas fa-download"></i>
                                                            </div>
                                                            <hr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                </div>
                                                </form>
                                            </div>

                                        </div>

                                    </div>
                                    <?php endif; ?>
                                    <?php elseif(auth()->user()->id_aktor == 3): ?>
                                    <a href="<?php echo e(route('editsigasi', $dg->id_sigasi)); ?>"
                                        class="btn btn-polda btn-action trigger--fire-modal-1" data-toggle="tooltip"
                                        title="">Edit Data</a>
                                    <?php endif; ?>
                                </td>
                                <td class="align-top">
                                    <?php if(auth()->user()->id_aktor==1): ?>
                                    <br>
                                    <a href="<?php echo e(route('hapussigasi', $dg->id_sigasi)); ?>"
                                        class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus data prestasi?');" data-toggle="tooltip"
                                        title=""><i class="fas fa-trash"></i> </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
			    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/dataprestasi.blade.php ENDPATH**/ ?>