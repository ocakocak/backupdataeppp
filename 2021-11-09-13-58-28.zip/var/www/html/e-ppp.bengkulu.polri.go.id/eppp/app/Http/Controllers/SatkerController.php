<?php

namespace App\Http\Controllers;

use App\Models\Satker;
use App\Models\Kesatuan;
use Illuminate\Http\Request;

class SatkerController extends Controller
{
    public function index()
    {
        if (auth()->user()->id_aktor == 1) {
            $data_satker = Satker::all();
            $data_kesatuan = Kesatuan::all();
        } elseif (auth()->user()->id_aktor == 2) {
            $data_satker = Satker::where('id_kesatuan', auth()->user()->id_kesatuan)->get();
            $data_kesatuan = Kesatuan::where('id_kesatuan', auth()->user()->id_kesatuan)->first();
        }
        return view('admin.satker.datasatker', compact("data_satker", "data_kesatuan"));
    }

    public function edit($id_satker)
    {
        if (auth()->user()->id_aktor == 1) {
            $data_satker = Satker::find($id_satker);
            $data_kesatuan = Kesatuan::all();
        } elseif (auth()->user()->id_aktor == 2) {
            $data_satker = Satker::find($id_satker);
            $data_kesatuan = Kesatuan::where('id_kesatuan', auth()->user()->id_kesatuan)->first();
        }
        return view('admin.satker.editsatker', compact("data_satker", "data_kesatuan"));
    }

    public function tambah()
    {
        if (auth()->user()->id_aktor == 1) {
            $data_kesatuan = Kesatuan::all();
        } elseif (auth()->user()->id_aktor == 2) {
            $data_kesatuan = Kesatuan::where('id_kesatuan', auth()->user()->id_kesatuan)->first();
        }
        return view('admin.satker.tambahsatker', compact("data_kesatuan"));
    }

    public function tambahdata(Request $request)
    {
        $data_satker = new Satker;
        $data_satker->satkers = $request->satkers;
        $data_satker->id_kesatuan = $request->id_kesatuan;
        $data_satker->save();
        $data_satker = satker::all();
        return redirect()->route('datasatker')->with(['success' => 'Data satker berhasil ditambah.']);
    }

    public function editdata(Request $request, $id_satker)
    {
        $data_satker = Satker::find($id_satker);
        $data_satker->update([
            'satkers' => $request->satkers,
            'id_kesatuan' => $request->id_kesatuan,
        ]);
        $data_satker->save();
        $data_satker = satker::all();
        return redirect()->route('datasatker')->with(['success' => 'Data satker berhasil diubah.']);
    }

    public function hapus(Request $request, $id_satker)
    {
        $data_satker = Satker::find($id_satker);
        $data_satker->delete();
        $data_satker = satker::all();
        return redirect()->route('datasatker')->with(['danger' => 'Date personel berhasil dihapus.']);
    }
}
