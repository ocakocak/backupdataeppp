<?php

namespace App\Http\Controllers;

use App\Models\Info;
use App\Models\Berita;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class LandingController extends Controller
{
    public function index()
    {
        $title = 'Selamat Datang';
        $info = Info::all();
        $berita = Berita::all();
        return view('welcome', compact('title', 'info', 'berita'));
    }
    public function tampiluu()
    {
        $title = 'Selamat Datang';
        $info = Info::all();
        $berita = Berita::all();
        return view('tampiluu', compact('title', 'info', 'berita'));
    }

    public function login()
    {
        $title = 'Silahkan Login';
        $info = Info::all();
        $berita = Berita::all();
        return view('sigasi.landing.login', compact('title', 'info', 'berita'));
    }

    public function depan()
    {
        $title = 'Selamat Datang';
        $info = Info::all();
        $berita = Berita::all();
        return view('sigasi.landing.depan', compact('title', 'info', 'berita'));
    }

    public function berita()
    {
        $title = 'Olah Data Berita';
        $judul = 'Olah Data Berita';
        $info = Info::all();
        $berita = Berita::all();
        return view('sigasi.landing.berita', compact('title', 'judul', 'info', 'berita'));
    }

    public function editberita($id_berita)
    {
        $title = 'Olah Data berita';
        $judul = 'Edit Data berita';
        $berita = Berita::where('id_berita', $id_berita)->first();
        // $berita = Berita::where('id_berita', $id_berita)
        $id_berita = $id_berita;
        return view('sigasi.landing.editberita', compact('title', 'judul', 'berita', 'id_berita'));
    }

    public function updateberita($id_berita, Request $request)
    {
	$data_berita = Berita::find($id_berita);
	$data_berita->judul = $request->judul;
	$data_berita->isi = $request->isi;

	if ($request->hasFile('gambar')) {
	    //hapus old image
            Storage::disk('local')->delete('public/berita/'. $data_berita->gambar);

            //upload new image
            $file=$request->gambar;
            $filenameWithExt = $file->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extensionsurat = $file->getClientOriginalExtension();
            $filenameSimpanGambar = $request->judul . $file->getClientOriginalName();
            $path1 = $file->storeAs('public/berita/', $filenameSimpanGambar);

            $data_berita->gambar = $filenameSimpanGambar;

        }

	$data_berita->save();
	$berita = Berita::all();
dd($data_berita);
        return redirect()->route('berita', compact("berita"))->with(['success' => 'Berita berhasil di ubah.']);
    }

    public function hapusberita($id_berita)
    {
        $berita = Berita::find($id_berita);
        $berita->delete();
        return redirect()->route('berita', compact("berita"));
    }


    public function tambahberita(Request $request)
    {
        if ($request->hasFile('gambar')) {
            $file=$request->gambar;
            $filenameWithExt = $file->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extensionsurat = $file->getClientOriginalExtension();
            $filenameSimpanGambar = $request->judul . $file->getClientOriginalName();
            $path1 = $file->storeAs('public/berita/', $filenameSimpanGambar);
            Berita::create([
                'judul' => $request->judul,
                'isi' => $request->isi,
                'status' => 1,
                'gambar' => $filenameSimpanGambar
            ]);
        } else {
            Berita::create([
                'judul' => $request->judul,
                'isi' => $request->isi,
                'status' => 1,
                'gambar' => 'logo.png'
            ]);
        }

        return redirect()->route('berita')->with(['success' => 'Berita berhasil ditambahkan.']);
    }

    public function info()
    {
        $title = 'Olah Data Informasi';
        $judul = 'Olah Data Informasi';
        $info = Info::all();
        $berita = Berita::all();
        return view('sigasi.landing.info', compact('title', 'judul', 'info', 'berita'));
    }

    public function editinfo($id_info)
    {
        $title = 'Olah Data Informasi';
        $judul = 'Edit Data Informasi';
        $info = Info::where('id_info', $id_info)->first();
        // dd($info);
        // Info::where('id_info', $id_info)->get();

        // $berita = Berita::where('id_berita', $id_berita)
        $id_info = $id_info;
        return view('sigasi.landing.editinfo', compact('title', 'judul', 'info', 'id_info'));
    }


    public function hapusinfo($id_info)
    {
        $info = Info::find($id_info);
        $info->delete();
        return redirect()->route('info', compact("info"));
    }

    public function updateinfo($id_info, Request $request)
    {
        $info = Info::find($id_info);
        $info->update($request->all());
        return redirect()->route('info', compact("info"));
    }

    public function tambahinfo(Request $request)
    {
        $data = new Info();
        // $data->id_personil = $request->id_personil;
        $data->judul = $request->judul;
        $data->informasi = $request->info;
        $data->status = 1;
        $data->save();
        // Personil::create($request->all());
        $data = Info::where('id_info')->get();
        return redirect()->route('info', compact("data"));
    }
}
