<?php $__env->startSection('content'); ?>
<div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
    <a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('datasigasiprestasi')); ?>">
        <i class="fas fa-arrow-circle-left"></i></i> Kembali
    </a>
    <div class="card-header">
        UPLOAD KEP PENGHARGAAN
    </div>
    <div class="card-body p-0">
        <?php $__currentLoopData = $data_sigasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('beripenghargaan',$dg->id_sigasi)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <input name="id_sigasi" id="id_sigasi" type="hidden" class="form-control" value="<?php echo e($dg->id_sigasi); ?>">
            <div class="form-group">
                <label>Uraian Prestasi</label>
                <input type="text" name="nama_prestasi" value="<?php echo e($dg->nama_prestasi); ?>" class="form-control" readonly>
            </div>
            <div class="form-group row mr-3 ml-3">
                <label style="font-size: 15px;">File Bukti Prestasi</label>
                <?php $databukti = App\Models\BuktiPrestasi::where('id_sigasi', $dg->id_sigasi)->get(); ?>
                <?php $__currentLoopData = $databukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="col-sm-11" href="<?php echo e(route('lihatbuktisigasi', $databukti->id_bukti_prestasi)); ?>"><?php echo e($databukti->file_bukti_prestasi); ?></a>
                <div class="col-sm-1">
                    <i class="fas fa-download"></i>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr style="background-color:red">
            <div class="form-group">
                <label>Nama Penghargaan</label>
                <input type="text" name="nama_penghargaan" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Keterangan Penghargaan</label>
                <input type="text" name="keterangan_penghargaan" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Jenis Penghargaan</label>
                <select class="form-control" name="jenis_penghargaan" required>
                    <option value="" style="color: grey;" disabled selected>-Pilih Jenis Penghargaan-</option>
                    <option value="KPLB">KPLB
                    </option>
                    <option value="KPLBA">KPLBA</option>
                    <option value="Promosi Mengikuti Pendidikan">Promosi Mengikuti Pendidikan</option>
                    <option value="Promosi Jabatan">Promosi Jabatan</option>
                    <option value="Tanda Penghargaan">Tanda Penghargaan</option>
                </select>
            </div>
            <div class="form-group">
                <label>Pemberi Penghargaan</label>
                <input type="text" name="sumber" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Unggah file bukti</label>
                <input name="file_bukti_penghargaan[]" type="file" class="form-control" multiple="true">
            </div>
            <button type="submit" class="btn btn-polda" style="float:right;color:white">Simpan</button>
        </form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/tambahpenghargaan.blade.php ENDPATH**/ ?>