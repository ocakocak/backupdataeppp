<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <br>
    <div class="row col-md-12">
            <div class="col-md-3" align="left">
                <a href="<?php echo e(route('cetakpengguna')); ?>" class="btn btn-polda" style="color:white;"><i
                        class="fas fa-print"></i>
                    Cetak
                </a></div>
                <div class="col-md-6" align="center">
                <h4 style="color:#6a381f;text-align:center">Data User</h4>
                </div>
    </div>

    <hr>
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-9" align="left">
        <a href="<?php echo e(route('tambahpengguna')); ?>" class="btn btn-polda" style="color:white;"><i
                class="fas fa-user-plus"></i>
            Tambah User
        </a></div><br>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped">
                <tbody>
                    <tr style="width:100px">
                        <th style="width:5px">No</th>
                        <th style="width:150px">Satker</th>
                        <th style="width:150px">Kesatuan</th>
                        <th style="width:150px">Username</th>
			<th style="width:150px">Password</th>
                        <th style="width:50px"></th>
                    </tr>
                    <?php if($data_pengguna != null): ?>
                    <?php $__currentLoopData = $data_pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="jpid<?php echo e($item->id); ?>" style="width:100px">

                        <td class="align-top" style="width:5px"><br><?php echo e($loop->iteration); ?></td>
                        </td>
                        <td class="align-top" style="width:100px"><br>
                        <?php if($item->id_satker !== null): ?>
                        <?php echo e($item->satker->satkers); ?>

                        <?php endif; ?>
                        </td>
                        <td class="align-top" style="width:100px"><br><?php echo e($item->kesatuan->kesatuans); ?></td>
                        <td class="align-top" style="width:100px"><br><?php echo e($item->username); ?><br></td>
                        <td class="align-top" style="width:100px"><br><?php echo e($item->dekripsi); ?><br></td>
			<td class="align-top" style="width:150px">
                            <br><a style="color:white" href="<?php echo e(route('editpengguna', $item->id)); ?>"
                                class="btn btn-polda style=" color:white;"btn-action mr-1" data-toggle="tooltip"
                                title="" data-original-title="Edit"><i class="fas fa-pencil-alt"></i> </a>
                            <a href="<?php echo e(route('hapuspengguna', $item->id)); ?>"
                                class="btn btn-danger btn-action trigger--fire-modal-1" onclick="return confirm('Apakah Anda yakin ingin menghapus user?');"  data-toggle="tooltip"
                                title=""><i class="fas fa-trash"></i> </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="row col-md-12">

                <div class="col-md-3" align="left">

                </div>
            </div><br>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script>
    function toggle(source) {
        checkboxes = document.getElementsByName('idpengguna[]');
        for (var i = 0, n = checkboxes.length; i < n; i++) {
            checkboxes[i].checked = source.checked;
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/pengguna/datapengguna.blade.php ENDPATH**/ ?>