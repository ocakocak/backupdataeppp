<!DOCTYPE html>
<html>

<head>
    <title>Rekap Data Penghargaan Personel</title>
</head>

<body>
    <style type="text/css">
        body {
            font-family: serif;
            font-size: 12px;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        table th,
        table td {
            position: relative;
            border: 1px solid #3c3c3c;
            padding: 3px 8px;
            text-align: top;
        }

        a {
            background: blue;
            color: #fff;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
        }

    </style>

    <?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Rekap Data Penghargaan Personel.xls");
	?>

    <center>
        <h1>Rekap Data Penghargaan Personel</h1>
    </center>

    <table border="1">
        <tr>
            <th style="width:5px">
                No
            </th>
            <th style="width:50px">Tanggal Input</th>
            <th style="width:150px">Nama</th>
            <th style="width:150px">Pangkat</th>
            <th style="width:150px">NRP/NIP</th>
            <th style="width:150px">Jabatan</th>
            <th style="width:150px">Kesatuan</th>
            <th style="width:300px">Penghargaan</th>
            <th style="width:300px">Sumber Penghargaan</th>
            <th style="width:300px">Keterangan Penghargaan</th>
        </tr>
        <?php if($data_sigasi != null): ?>
        <?php $__currentLoopData = $data_sigasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($dg->jenis_penghargaan != null): ?>
        <tr style="width:1000px">
            <td style="width:30px" valign="top">
                <p><?php echo e($loop->iteration); ?></p>
            </td>
            <td style="width:50px" class="align-top text-justify"><br><?php echo e(date('d-m-Y', strtotime($dg->tanggal_input))); ?> </td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->nama); ?> </td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->pangkat->pangkats); ?></td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->nrpnip); ?> </td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->jabatan); ?></td>
            <td style="width:150px;text-align:justify" valign="top"><?php echo e($dg->personil->kesatuan->kesatuans); ?>

            </td>
            <td style="width:100px;text-align:justify" valign="top"><?php echo e($dg->nama_penghargaan); ?></td>
            <td style="width:100px;text-align:justify" valign="top"><?php echo e($dg->sumber); ?></td>
            <td style="width:100px;text-align:justify" valign="top"><?php echo e($dg->keterangan_penghargaan); ?></td>
            <!-- <td >
                                <?php if($dg->status_tindakan=='Belum Ditindak'): ?>
                                <br><a style="color:white"href="<?php echo e(route('tindaksigasi', $dg->id_sigasi)); ?>"class="btn btn-polda style="color:white btn-action mr-1" data-toggle="tooltip" title="" >Tindak Sekarang</a>  
                                <?php else: ?>
                                <br><a href="<?php echo e(route('tindaksigasi', $dg->id_sigasi)); ?>"class="btn btn-danger btn-action mr-1" data-toggle="tooltip" title="" data-original-title="Edit">Batal Tindak</a>  
                                <?php endif; ?>
                            </td> -->
        </tr>
	<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>
</body>

</html>
<?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/exportpenghargaan.blade.php ENDPATH**/ ?>