<?php $__env->startSection('content'); ?>
    <div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
<a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('berita')); ?>">
            <i class="fas fa-arrow-circle-left"></i></i> Kembali
        </a>
        
<div class="card-body p-0">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <h2 class="text-center"><?php echo e($judul); ?></h2>
                <hr>
                <form action="<?php echo e(route('updateberita', $berita->id_berita)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div class="col mx-auto">
                        <input type="hidden" id="id_berita" name="id_berita" value="<?php echo e($berita->id_berita); ?>" class="form-control"></input>
                        <div class="form-group col-md-8 mx-auto">
                            <label>Judul Berita</label>
                            <input type="text" id="judul" value="<?php echo e($berita->judul); ?>" name="judul" class="form-control" required></input>
                        </div>
                        <div class="form-group col-md-8 mx-auto">
                            <label>Isi Berita</label>
                            <textarea id="isi" rows="3" value="<?php echo e($berita->isi); ?>" name="isi" class="form-control" required><?php echo e($berita->isi); ?></textarea>
                        </div>
			<div class="form-group col-md-8 mx-auto">
                            <label>Gambar Berita</label>
                            <input type="file" id="gambar" name="gambar" value="<?php echo e($berita->gambar); ?>"class="form-control"></input>
                        </div>
                        <div class="mx-auto" style="text-align: center;">
                            <button class="btn btn-polda mx-auto" style="color: white;" type="submit">Edit Informasi</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/sigasi/landing/editberita.blade.php ENDPATH**/ ?>