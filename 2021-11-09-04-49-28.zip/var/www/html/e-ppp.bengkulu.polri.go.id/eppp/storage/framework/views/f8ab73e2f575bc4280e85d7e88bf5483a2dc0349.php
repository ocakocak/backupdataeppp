<?php echo e($slot); ?>

<?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>