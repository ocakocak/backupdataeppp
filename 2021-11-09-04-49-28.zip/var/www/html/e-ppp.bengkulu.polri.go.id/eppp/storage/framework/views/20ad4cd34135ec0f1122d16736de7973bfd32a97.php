<?php if($message = Session::get('success')): ?>
<div class="col-md-12">
      <div class="alert alert-success alert-block">
          <strong style="font-family:Roboto Slab; letter-spacing:2px"><?php echo e($message); ?></strong>
      </div>
</div>
<?php endif; ?>

<?php if($message = Session::get('danger')): ?>
<div class="col-md-12">
      <div class="alert alert-danger alert-block">
          <strong style="font-family:Roboto Slab; letter-spacing:2px"><?php echo e($message); ?></strong>
      </div>
</div>
<?php endif; ?>
<?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/alert.blade.php ENDPATH**/ ?>