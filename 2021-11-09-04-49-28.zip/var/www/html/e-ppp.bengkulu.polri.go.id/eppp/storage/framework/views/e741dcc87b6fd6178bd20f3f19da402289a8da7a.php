<?php $__env->startSection('content'); ?>
<div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
<a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('datasigasiprestasi')); ?>">
        <i class="fas fa-arrow-circle-left"></i></i> Kembali
    </a> 
   <div class="card-header">
        <h4>
            <button data-toggle="modal" data-target="#tambahPersonil" style="color: white;" class="btn btn-polda">
                <i class="fas fa-plus-circle"></i> &nbsp; Tambah Data Personel
            </button>
        </h4>
        <br>
    </div>
    <div class="card-body p-0">
        <form action="<?php echo e(route('updatedatasigasi',$data_sigasi->id_sigasi)); ?>" method="post"
            enctype="multipart/form-data">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <p style="color: #99582a; font-size:25px; font-weight:bold" class="text-center">Ubah Prestasi</p>

                <!-- DATA PERSONEL -->
                <p style="color:#6e0d25; font-weight:bold; font-size:20px">Data Personel</p>
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="name"><?php echo e(__('Nama Personel')); ?></label>
                                <select class="form-control" id="nama" name="nama">
                                    <?php if($data_sigasi->id_personil !== null): ?>
                                    <option value="<?php echo e($data_sigasi->id_personil); ?>"><?php echo e($data_sigasi->personil->nama); ?>

                                    </option>
                                    <?php $__currentLoopData = $data_personil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pr->id_personil); ?>"><?php echo e($pr->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $data_personil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pr->id_personil); ?>"><?php echo e($pr->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <hr>

                <!-- PRESTASI -->
                <p style="color:#6e0d25; font-weight:bold; font-size:20px">Ubah Prestasi</p>
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Uraian Prestasi</label>
                                <input name="nama_prestasi" value="<?php echo e($data_sigasi->nama_prestasi); ?>" type="text" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer text-right">
                <button class="btn btn-polda mr-1" style="color:white"type="submit"><i class="fas fa-save"></i></button>
                <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL TAMBAH DATA Personel -->

<div class="modal fade" id="tambahPersonil" tabindex="-1" aria-labelledby="tambahPersonilLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahPersonilLabel">Tambah Data Personel</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('tambahdatapersonil')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row mr-3 ml-3">
                        <label style="font-size: 15px;">Nama Personel</label>
                        <input name="nama" type="text" class="form-control">
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <label style="font-size: 15px;">NRP/NIP</label>
                        <input name="nrpnip" type="text" class="form-control">
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <label style="font-size: 15px;">Pangkat</label>
                        <select class="form-control" id="pangkat" name="pangkat">
                            <option disabled selected value="">-Pilih Pangkat-</option>
                            <?php $__currentLoopData = $data_pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id_pangkat); ?>"><?php echo e($p->pangkats); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group row mr-3 ml-3">
                        <label style="font-size: 15px;">Jabatan</label>
                        <input name="jabatan" type="text" class="form-control">
                    </div>
                    <!-- <div class="form-group row mr-3 ml-3">
                            <label style="font-size: 15px;">Kesatuan</label>
                            <input type="text" id="search" name="search" class="form-control" placeholder="Search">
                        </div> -->
                    <?php if(auth()->user()->id==1): ?>
                    <div class="form-group row mr-3 ml-3">
                        <label style="font-size: 15px;">Kesatuan</label>
                        <select class="form-control" id="kesatuan" name="kesatuan">
                            <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id_kesatuan); ?>"><?php echo e($k->kesatuans); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php else: ?>
                    <input name="kesatuan" type="hidden" value="<?php echo e(auth()->user()->id_kesatuan); ?>" class="form-control">
                    <?php endif; ?>
                    <button class="btn btn-polda mr-1" style="color: white;" type="submit"><i
                            class="fas fa-save"></i></button>
                    <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>

                </form>
            </div>

        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/sigasi/editsigasi.blade.php ENDPATH**/ ?>