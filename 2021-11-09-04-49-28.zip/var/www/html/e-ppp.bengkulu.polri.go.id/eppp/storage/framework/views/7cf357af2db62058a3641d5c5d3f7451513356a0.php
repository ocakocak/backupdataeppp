<?php $__env->startSection('content'); ?>
    <div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
        <div class="card-body p-0">
	<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <h2 class="text-center"><?php echo e($judul); ?></h2>
                <hr>
                <p style="text-align: center;font-family:Koh Santepheap; font-size:25px;color:#9d0208; font-weight:bold">Data Informasi</p>
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <tbody>
                            <tr style="width:100px">
                                <th rowspan="2">No</th>
                                <th rowspan="2">Judul</th>
                                <th rowspan="2">Isi</th>
                                <th colspan="2" style="text-align: center;">Aksi</th>
                            </tr>
                            <tr>
                                <th>Edit</th>
                                <th>Hapus</th>
                            </tr>
                            <?php if($info != null): ?>
                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"> <?php echo e($loop->iteration); ?> </td>
                                <td><?php echo e($p->judul); ?></td>
                                <td style="text-align:justify">
                                    <?php echo $p->informasi; ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('editinfo', $p->id_info)); ?>">
                                        <button class="btn btn-polda mx-auto" style="color: white;"><i class="fas fa-edit"></i></button>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('hapusinfo', $p->id_info)); ?>">
                                        <button class="btn btn-danger mx-auto" onclick="return confirm('Yakin ingin menghapus informasi?');"><i class="fas fa-trash-alt"></i></button>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <hr>
                <p style="text-align: center;font-family:Koh Santepheap; font-size:25px;color:#9d0208; font-weight:bold">Tambah Informasi</p>
                <form action="<?php echo e(route('tambahinfo')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="col mx-auto">
                        <div class="form-group col-md-8 mx-auto">
                            <label>Judul Informasi</label>
                            <input type="text" id="judul" name="judul" class="form-control" required></input>
                        </div>
                        <div class="form-group col-md-8 mx-auto">
                            <label>Isi Informasi</label>
                            <textarea id="info" rows="3" name="info" class="form-control" required></textarea>
                        </div>
                        <div class="mx-auto" style="text-align: center;">
                            <button class="btn btn-polda mx-auto" style="color: white;" type="submit">Tambah Informasi</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/sigasi/landing/info.blade.php ENDPATH**/ ?>