<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <h4 style="color:#6a381f">Formulir Ubah Akun</h4>
    </div>
    <div class="card-body p-0">
	<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('updateuser', $data_user->id)); ?>" method="post" enctype="multipart/form-data">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="row">
                    <!-- <center>
                    <img style="width:150px;float:center;"src="../assets/img/avatar/avatar-1.png" class="rounded-circle"><br>
			</center> -->
                    <div class="col-md-12 row">

                        <div class="col-md-4 form-group">
                            <label>Username</label>
                            <input type="text" value="<?php echo e($data_user->username); ?>" name="username" class="form-control" required>
                        </div>
                        <input type="hidden" value="<?php echo e($data_user->id_kesatuan); ?>" name="id_kesatuan"
                            class="form-control">

                    </div>
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-polda mr-1" style="color:white" type="submit"><i
                        class="fas fa-save"></i></button>
            </div>
        </form>
    </div>

    <hr style="background-color:red">
    <div class="card-header">
        <h4 style="color:#6a381f">Formulir Ubah Password</h4>
    </div>
    <div class="card-body p-0">
        <form action="<?php echo e(route('updatepassword', $data_user->id)); ?>" method="post" enctype="multipart/form-data">
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="row">
                    <!-- <center>
                    <img style="width:150px;float:center;"src="../assets/img/avatar/avatar-1.png" class="rounded-circle"><br>
</center> -->
                    <div class="col-md-12 row">

                        <input type="hidden" value="<?php echo e($data_user->username); ?>" name="username" class="form-control">
                        <div class="col-md-4 form-group">
                            <label>Password Lama</label>
                            <input type="text" name="passwordlama" class="form-control" value="<?php echo e($data_user->dekripsi); ?>" readonly required>
                        </div>
			<div class="col-md-4 form-group">
                            <label>Password Baru</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-4 form-group">
                            <label>Konfirmasi Password Baru</label>
                            <input type="password" name="konfirmasipassword" class="form-control"required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer text-right">
                <button class="btn btn-polda mr-1" style="color:white" type="submit"><i
                        class="fas fa-save"></i></button>
                <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/admin/user/edituser.blade.php ENDPATH**/ ?>