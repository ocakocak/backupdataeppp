<?php $__env->startSection('content'); ?>
                    <div class="card card-primary">
			<a style="color:#6a381f" class="ml-3 pl-1 mt-3" href="<?php echo e(route('dataadmin')); ?>">
        <i class="fas fa-arrow-circle-left"></i></i> Kembali
    </a>
                        <div class="card-header">
                            <h4 style="color:#6a381f">Formulir Tambah Admin</h4>
                        </div>
                        <div class="card-body p-0">
                            <form action="<?php echo e(route('tambahdataadmin')); ?>" method="post" enctype="multipart/form-data">
                                <div class="card-body">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">

                                        <div class="col-md-4 form-group">
                                            <label>Kesatuan</label>
                                            <div class="row ml-1" style="height:40px">
                                                <select class="select" id="id_kesatuan" name="id_kesatuan" required>
                                                    <div>
							<option value="" style="color: grey;" disabled selected>-Pilih Kesatuan-</option>
                                                        <?php if($data_kesatuan != null): ?>
                                                        <?php $__currentLoopData = $data_kesatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $djs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($djs->id_kesatuan); ?>"><?php echo e($djs->kesatuans); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </div>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-4 form-group">
                                            <label>Username</label>
                                            <input type="text" name="username" class="form-control" required>
                                        </div>
                                        <div class="col-md-4 form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="card-footer text-right">
                            <button class="btn btn-polda mr-1" style="color:white" type="submit"><i
                                    class="fas fa-save"></i></button>
                            <button class="btn btn-danger" type="reset"><i class="fas fa-eraser"></i></button>
                        </div>
                        </form>
                    </div>
                </div>
               <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/e-ppp.bengkulu.polri.go.id/eppp/resources/views/superadmin/admin/tambahadmin.blade.php ENDPATH**/ ?>