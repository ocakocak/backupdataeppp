@extends('layouts.backendadmin')

@section('content')
<div class="card" style="border-top-width: 0.2cm; border-top-color: #6a381f">
    <div class="card-body p-0">
        <div class="card-body">
        <p class="text-center"> <h4 class="text-center" style="color:black">Jenis dan Syarat Penghargaan</h4></p>
            <hr>
            <iframe src='JENIS PENGHARGAAN DAN SYARAT.pdf' width="1000" height="1200"></iframe>
        </div>
    </div>
</div>


@endsection
