@include('templateuser.header2')

@include('templateuser.topnav3')

@yield('content')

@include('templateuser.footer2')