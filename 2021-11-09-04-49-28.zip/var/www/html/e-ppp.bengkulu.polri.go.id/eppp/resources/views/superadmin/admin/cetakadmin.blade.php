<html>

<head>
    <title>Data Admin e-PPP</title>

    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <meta content="" name="description">

    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="{{asset('templateuser/assets/img/logofixspi.png')}}" rel="icon">
    <link href="{{asset('templateuser/assets/img/apple-touch-icon.png')}}" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="{{asset('templateuser/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('templateuser/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
    <link href="{{asset('templateuser/assets/vendor/aos/aos.css')}}" rel="stylesheet">
    <link href="{{asset('templateuser/assets/vendor/remixicon/remixicon.css')}}" rel="stylesheet">
    <link href="{{asset('templateuser/assets/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">
    <link href="{{asset('templateuser/assets/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="{{asset('templateuser/assets/css/style.css')}}" rel="stylesheet">
    <style>
        .container {
            /* Used to position the watermark */
            position: center;
        }

        .container__wrapper {
            /* Center the content */
            align-items: center;
            display: flex;
            justify-content: center;

            /* Absolute position */
            left: 0px;
            position: absolute;
            top: 0px;

            /* Take full size */
            height: 100%;
            width: 100%;
        }

        .container__watermark {
            /* Text color */
            color: rgba(0, 0, 0, 0.2);

            /* Text styles */
            font-size: 3rem;
            font-weight: bold;
            text-transform: uppercase;

            /* Rotate the text */

            /* Disable the selection */
            user-select: none;
        }

    </style>
    <style>
        body {
            font-family: Arial;
            font-size: 12px
        }

    </style>
    <style type="text/css">
        .page {}

        .left {
            text-align: left;
        }

        .right {
            text-align: right;
        }

        .center {
            text-align: center;
        }

        .justify {
            text-align: justify;
        }

        .contoh1 {
            font-size: 16px;
        }

        .inden {
            text-indent: 100px;
        }

        .inden2 {
            text-indent: 105px;
        }

        .inden3 {
            text-indent: 150px;
        }

        .line-title {
            border-style: inset;
            border-top: 1px solid #000;
        }

    </style>
</head>

<body>
    <div class="page">
        <div class="container">
            <!-- Watermark container -->
            <div class="container__wrapper">
                <!-- The watermark -->
                <div class="container__watermark">
                    <img src="{{ asset('assets/img/sdmpolri.png')}}" style="opacity:20%" alt="">
                </div>
            </div>
            <center>
                <h3>Data Admin e-PPP</h3>
            </center>
	    <center>
            <table border="1">
            		<tr>
                            <th>No</th>
                            <th>Kesatuan</th>
                            <th>Username</th>

                        </tr>
			
                        @if ($data_admin != null)
                        @foreach ($data_admin as $key => $item)
                        <tr>
			<td class="align-top" >{{$loop->iteration}}</td>
                        <td class="align-top" >{{ $item->kesatuan->kesatuans }}</td>
                        <td class="align-top" >{{ $item->username }}<br></td>
                        </tr>
                        @endforeach
                        @endif
	    </table>
	    </center>
        <script src="{{ asset('temp/assets/vendor/jquery/jquery.min.js') }}"></script>
        <script src="{{ asset('temp/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

        <!-- Core plugin JavaScript-->
        <script src="{{ asset('temp/assets/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

        <!-- Custom scripts for all pages-->
        <script src="{{ asset('temp/assets/js/sb-admin-2.min.js') }}"></script>

        <!-- Page level plugins -->
        <script src="{{ asset('temp/assets/vendor/chart.js/Chart.min.js') }}"></script>

        <!-- Page level custom scripts -->
        <script src="{{ asset('temp/assets/js/demo/chart-area-demo.js') }}"></script>
        <script src="{{ asset('temp/assets/js/demo/chart-pie-demo.js') }}"></script>

        <script src="{{ asset('vendor/sweetalert2/sweetalert2.all.min.js') }}"></script>
        <script>
            window.print()

        </script>
</body>

</html>
