@include('templateuser.header2')

@include('templateuser.topnav2')

@yield('content')

@include('templateuser.footer2')