
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_aktor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_aktor` (
  `id_aktor` int NOT NULL,
  `aktor` varchar(11) NOT NULL,
  PRIMARY KEY (`id_aktor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_aktor` WRITE;
/*!40000 ALTER TABLE `tb_aktor` DISABLE KEYS */;
INSERT INTO `tb_aktor` VALUES (1,'superadmin'),(2,'admin'),(3,'user'),(4,'admininfo'),(5,'userpolda');
/*!40000 ALTER TABLE `tb_aktor` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_berita` (
  `id_berita` int NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `isi` text NOT NULL,
  `gambar` text,
  PRIMARY KEY (`id_berita`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_berita` WRITE;
/*!40000 ALTER TABLE `tb_berita` DISABLE KEYS */;
INSERT INTO `tb_berita` VALUES (11,'Polda Bengkulu Sabet Enam Kategori Treasury Advisor Award 2021 KPPN Bengkulu','<p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\"><strong style=\"font-weight: bold;\"><em>Tribratanewsbengkulu.bengkulu.polri.go.id, BENGKULU –&nbsp;</em></strong>Prestasi gemilang kembali diukir Polda Bengkulu. Pasalnya Satuan Kerja Polda Bengkulu menyabet enam kategori dalam penghargaan Treasury Advisor Award 2021 yang diselenggarakan KPPN Bengkulu, Kamis (28/10/2021).</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Keenam kategori tersebut ialah Bidang Keuangan Polda Bengkulu meraih juara satu dalam kategori kordinasi dan komitmen pimpinan dalam pelaksanaan anggaran. Selanjutnya Biro Rena Polda Bengkulu menerima penghargaan juara satu dalam kategori ketepatan waktu penyampaian dan kelengkapan dokumen hardcopy SPM. Juara satu juga diraih oleh Dit Reskrimum Polda Bengkulu dalam kategori Nilai IKPA Tertinggi Satker Pagu Besar sementara itu Satbrimob juara dua.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Penghargaan dalam kategori penyusunan dan penyelesaian laporan keuangan juga diterima oleh Ditlantas Polda Bengkulu yang menduduki peringkat kedua sementara Bidang TIK meraih juara ketiga. Selanjutnya untuk kategori komitmen dan kesiapan implementasi “SAKTI” Polres Bengkulu meraih juara dua. Dan terakhir Bid Humas Polda Bengkulu meraih juara kedua dalam katergori nilai IKPA tertinggi Satker Pagu Sedang dan Ditbinmas Meraih jura ketiga.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Pada kesempatan itu Kabid&nbsp; Keuangan Polda Bengkulu Kombespol. Bambang Kusnarianto, S.Ik &nbsp;mengucapkan terima kasih dan apresiasi kepada KPPN Bengkulu yang telah memberikan penghargaan kepada Polda Bengkulu. Ia menyampaikan dengan diberikan penghargaan ini, Polda Bengkulu akan terus berkreasi serta meningkatkan kerjasama dan kordinasi demi memperbaiki kinerja dan pelayanan kepada masyarakat.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">“terima kasih kepada KPPN Bengkulu selaku pembina dan mitra kerja yang terus membantu dalam hal pembenahan administrasi dan pelaporan Polda Bengkulu,” ucanya.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Tampak hadir pada kesempatan itu Karo Rena Polda Bengkulu, Direktur Reskrimum, Direktur Binmas, Kapolres Bengkulu, Wadir Ditlantas dan Kasubdit Penmas Polda Bengkulu.</p>','Polda Bengkulu Sabet Enam Kategori Treasury Advisor Award 2021 KPPN BengkuluScreenshot (55).png'),(12,'Polda Bengkulu Beri 970 Vaksinator Penghargaan','<p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\"><strong style=\"font-weight: bold;\"><em>Tribratanewsbengkulu.polri.BENGKULU –&nbsp;</em></strong>Sebanyak 970 orang relawan yang bersumber dari civitas Akademika dibidang kesehatan yang di rekrut di 7 Perguruan tinggi yang ada di Provinsi Bengkulu mendapatkan piagam penghargaan dari Polda Bengkulu.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Penyerahan piagam Penghargaan tersebut diserahkan langsung oleh Wakapolda Bengkulu Brigjen Pol Hari Prasodjo, M.H pagi tadi,(28/10/2021) di Aula Adem Mapolda Bengkulu.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Adapun piagam penghargaan yang diberikan kepada 970 orang lebih relawan kemanusiaan yang di rekrut melalui 7 universitas di provinsi bengkulu tersebut yakni sebagai tenaga vaksinator dan administrator vaksinasi covid 19 di provinsi bengkulu.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Penerimaan piagam penghargaan ini sendiri diwakili oleh 11 orang mahasiswa yang menjadi relawan kemanusian sebagai tenaga vaksinator dan administrator.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Ketika diwawancarai, Wakapolda Bengkulu mengatakan,pemberian penghargaan ini sebagai bentuk apresiasi terhadap para relawan kemanusiaan yang membantu polri dalam vaksinasi terhadap masyarakat bengkulu.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Selain itu, Wakapolda juga mengapresiasi para mahasiswa yang telah bersedia membantu polri menjadi tenaga vaksinator dan administrator guna mencapai target capaian 1 koma 5 juta orang penduduk provinsi bengkulu selesai di vaksin covid 19.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">&nbsp;” Kita hari ini memberikan piagam penghargaan terhadap para relawan kemanusiaan yang terdiri dari para mahasiswa yang telah membantu kita dalam program vaksinasi covid 19 untuk masyarakat provinsi bengkulu”. Kata Wakapolda Bengkulu.</p><p style=\"text-align: justify; margin-bottom: 20px; color: rgb(53, 53, 53); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 13px;\">Wakapolda juga menyampaikan,para relawan tenaga vaksinator dan administrator ini akan terus membantu polri dalam hal vaksinasi masyarakat bengkulu dan vaksinasi ini sendiri akan terus dilakukan polda bengkulu dan jajaran mengingat capaian vaksinasi di bengkulu masih tergolong rendah.</p>','Polda Bengkulu Beri 970 Vaksinator PenghargaanIMG-20211028-WA0026.jpg');
/*!40000 ALTER TABLE `tb_berita` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_bukti_penghargaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_bukti_penghargaan` (
  `id_bukti_penghargaan` int NOT NULL AUTO_INCREMENT,
  `id_sigasi` int NOT NULL,
  `file_bukti_penghargaan` text NOT NULL,
  `extension` varchar(25) NOT NULL,
  PRIMARY KEY (`id_bukti_penghargaan`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_bukti_penghargaan` WRITE;
/*!40000 ALTER TABLE `tb_bukti_penghargaan` DISABLE KEYS */;
INSERT INTO `tb_bukti_penghargaan` VALUES (19,17,'db_ep3fix.sql','sql'),(20,17,'db_ep3 (1).sql','sql'),(21,18,'Untitled.png','png'),(22,19,'sahabatpsikologi.png','png'),(23,20,'Soal Try Out 3.pdf','pdf'),(24,21,'rekap to sampai tanggal 27082021.xlsx','xlsx'),(25,22,'LAPORAN PRAKTIKUM KE-2 PCD_FEBRIDILA NURUL MASYITA_G1A018027.pdf','pdf'),(26,23,'File Bukti 2.pdf','pdf'),(27,23,'1.png','png'),(28,24,'5.png','png'),(29,25,'38.png','png'),(30,27,'9.png','png'),(31,29,'USULAN TES PSIKOLOGI.pdf','pdf'),(32,30,'1.jfif','jfif'),(33,28,'File Bukti 1.docx','docx'),(34,31,'File Bukti 1.docx','docx'),(35,32,'httpssahabatprofessionalindonesia.com.png','png'),(36,33,'1.jfif','jfif'),(37,34,'Rekap Data Prestasi Personel (7).xls','xls'),(38,35,'AZ-900T00 Microsoft Azure Fundamentals-02 (workloads)_FINAL.pptx','pptx'),(39,31,'1.png','png'),(41,37,'Doc2.docx','docx'),(42,38,'Doc2 (2).docx','docx'),(43,38,'Doc2 (2).docx','docx'),(44,40,'AI20-B-UTS-RIDHA NAFILA-G1A019017.pdf','pdf'),(45,41,'Logic_programming_for_combinatorial_problems.pdf','pdf'),(46,43,'2392-5654-1-PB.pdf','pdf'),(47,36,'Seleksi Terbuka Jabatan Pimpinan Tinggi Pratama Di Lingkungan Pemerintah Kota Bengkulu BKPP Kota Bengkulu Tahun Anggaran 2021 (2).png','png'),(48,36,'spk wkwk (1).pptx','pptx'),(49,61,'PENGHARGAAN.docx','docx'),(50,62,'PENGHARGAAN.docx','docx'),(54,67,'FILE BUKTI 2.docx','docx');
/*!40000 ALTER TABLE `tb_bukti_penghargaan` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_bukti_prestasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_bukti_prestasi` (
  `id_bukti_prestasi` int NOT NULL AUTO_INCREMENT,
  `id_sigasi` int NOT NULL,
  `file_bukti_prestasi` text NOT NULL,
  `extension` varchar(25) NOT NULL,
  PRIMARY KEY (`id_bukti_prestasi`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_bukti_prestasi` WRITE;
/*!40000 ALTER TABLE `tb_bukti_prestasi` DISABLE KEYS */;
INSERT INTO `tb_bukti_prestasi` VALUES (27,15,'Screenshot (388).png','png'),(28,14,'Screenshot (388).png','png'),(29,15,'B9D72073-F2B6-408B-BBE5-366826E178E1.pdf','pdf'),(30,15,'B9D72073-F2B6-408B-BBE5-366826E178E1.pdf','pdf'),(31,17,'httpssahabatprofessionalindonesia.com.png','png'),(32,17,'46a7b3c6-a80b-4839-bacf-acf56e9b682e.jpg','jpg'),(33,18,'B9D72073-F2B6-408B-BBE5-366826E178E1.pdf','pdf'),(34,19,'Rekap Data Penghargaan Personel (1).xls','xls'),(35,19,'B9D72073-F2B6-408B-BBE5-366826E178E1.pdf','pdf'),(36,20,'LAPORAN PRAKTIKUM KE-2 PCD_FEBRIDILA NURUL MASYITA_G1A018027.docx','docx'),(37,21,'DESAIN KAOS.docx','docx'),(38,22,'Cetak Rencana Studi - Portal Akademik.pdf','pdf'),(39,23,'Invoice Sahabat psikologi.pdf','pdf'),(41,25,'31.png','png'),(42,26,'1.png','png'),(43,27,'4.png','png'),(44,28,'COBA.docx','docx'),(45,29,'Screenshot (1421).png','png'),(47,31,'WhatsApp Image 2021-10-07 at 13.46.52.jpeg','jpeg'),(48,35,'AZ-900T00 Microsoft Azure Fundamentals-02 (workloads)_FINAL.pptx','pptx'),(49,35,'Untitled-1.png','png'),(50,36,'JENIS PENGHARGAAN DAN SYARAT.pdf','pdf'),(51,37,'Doc2.docx','docx'),(52,38,'download (1).jfif','jfif'),(53,29,'1.png','png'),(54,29,'5.png','png'),(55,29,'Kuliah 1 - Pengantar SPK [Compatibility Mode] (1).pdf','pdf'),(56,39,'2392-5654-1-PB.pdf','pdf'),(57,40,'AI20-B-UTS-RIDHA NAFILA-G1A019017.pdf','pdf'),(59,29,'WhatsApp Image 2021-09-09 at 14.52.52.jpeg','jpeg'),(62,41,'2392-5654-1-PB.pdf','pdf'),(63,42,'2392-5654-1-PB.pdf','pdf'),(64,43,'AI20-B-UTS-RIDHA NAFILA-G1A019017.pdf','pdf'),(66,43,'Logic_programming_for_combinatorial_problems.pdf','pdf'),(68,44,'2392-5654-1-PB.pdf','pdf'),(69,45,'JENIS PENGHARGAAN DAN SYARAT (2).docx','docx'),(70,46,'JENIS PENGHARGAAN DAN SYARAT (2).docx','docx'),(72,49,'2.png','png'),(73,49,'Untitled.png','png'),(74,50,'2392-5654-1-PB.pdf','pdf'),(75,51,'File bukti  (1).docx','docx'),(76,51,'File bukti  (2).docx','docx'),(77,51,'File bukti  (3).docx','docx'),(78,51,'File bukti  (4).docx','docx'),(79,52,'File bukti  (1).docx','docx'),(80,52,'File bukti  (2).docx','docx'),(81,52,'File bukti  (3).docx','docx'),(82,52,'File bukti  (4).docx','docx'),(83,53,'REKAP E MENTAL.jpg','jpg'),(84,55,'WhatsApp Image 2021-09-07 at 13.17.09.jpeg','jpeg'),(85,56,'File bukti  (1).docx','docx'),(86,57,'File bukti  (3).docx','docx'),(87,58,'File bukti  (1).docx','docx'),(88,58,'File bukti  (2).docx','docx'),(89,59,'REKAP PESERTA TRY OUT CAT PSI 2020.xlsx','xlsx'),(90,60,'2.jpg','jpg'),(92,61,'FILE BUKTI.docx','docx'),(93,62,'FILE BUKTI.docx','docx'),(94,62,'FILE BUKTI 2.docx','docx'),(95,61,'FILE BUKTI 2.docx','docx'),(96,62,'FILE BUKTI 2.docx','docx'),(99,66,'FILE BUKTI.docx','docx'),(100,67,'FILE BUKTI.docx','docx'),(101,66,'FILE BUKTI 2.docx','docx'),(102,67,'FILE BUKTI 2.docx','docx'),(103,66,'FILE BUKTI 3.docx','docx'),(106,70,'File bukti  (4).docx','docx'),(122,79,'ND Satya Lencana.docx','docx'),(124,82,'DOA SYUKURAN HUT BHYANGKARA KE 75.docx','docx'),(126,84,'UNDANGAN (1).docx','docx'),(174,114,'CamScanner 10-29-2021 11.45.pdf','pdf');
/*!40000 ALTER TABLE `tb_bukti_prestasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_info` (
  `id_info` int NOT NULL,
  `judul` varchar(40) NOT NULL,
  `informasi` text NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id_info`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_info` WRITE;
/*!40000 ALTER TABLE `tb_info` DISABLE KEYS */;
INSERT INTO `tb_info` VALUES (1,'Apa itu aplikasi e-PPP ?','e-PPP merupakan sebuah Sistem informasi yang menampung data personel berprestasi dan data penerima penghargaan di Polda Bengkulu.\r\n\r\n    e-PPP memanfaatkan teknologi untuk menyediakan data personel berprestasi dan data penerima penghargaan secara cepat dan berkesinambungan',1),(2,'Layanan aplikasi e-PPP','Pada aplikasi ini memberikan kemudahan dalam pengelolaan data mulai dari pendataan prestasi dan juga penghargaan personil disertai dengan rekapan data.',1);
/*!40000 ALTER TABLE `tb_info` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_kesatuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_kesatuan` (
  `id_kesatuan` int NOT NULL,
  `kesatuans` varchar(35) NOT NULL,
  PRIMARY KEY (`id_kesatuan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_kesatuan` WRITE;
/*!40000 ALTER TABLE `tb_kesatuan` DISABLE KEYS */;
INSERT INTO `tb_kesatuan` VALUES (1,'POLRES BENGKULU'),(2,'POLRES BENGKULU TENGAH'),(3,'POLRES BENGKULU UTARA'),(4,'POLRES BENGKULU SELATAN'),(5,'POLRES REJANG LEBONG'),(6,'POLRES LEBONG'),(7,'POLRES SELUMA'),(8,'POLRES KAUR'),(9,'POLRES MUKO-MUKO'),(10,'POLRES KEPAHIANG'),(11,'POLDA BENGKULU');
/*!40000 ALTER TABLE `tb_kesatuan` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_pangkat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pangkat` (
  `id_pangkat` int NOT NULL,
  `pangkats` varchar(40) NOT NULL,
  PRIMARY KEY (`id_pangkat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_pangkat` WRITE;
/*!40000 ALTER TABLE `tb_pangkat` DISABLE KEYS */;
INSERT INTO `tb_pangkat` VALUES (1,'JENDERAL POLISI'),(2,'KOMJENPOL'),(3,'IRJENPOL'),(4,'BRIGJENPOL'),(5,'KOMBES'),(6,'AKBP'),(7,'KOMPOL'),(8,'AKP'),(9,'IPTU'),(10,'IPDA'),(11,'AIPTU'),(12,'AIPDA'),(13,'BRIPKA'),(14,'BRIGPOL'),(15,'BRIPTU'),(16,'BRIPDA'),(17,'ABRIP'),(18,'ABRIPTU'),(19,'ABRIPDA'),(20,'BHARAKA'),(21,'BHARATU'),(22,'BHARADA'),(23,'PEMBINA UTAMA'),(24,'PEMBINA UTAMA MADYA'),(25,'PEMBINA UTAMA MUDA'),(26,'PEMBINA TINGKAT I'),(27,'PEMBINA'),(28,'PENATA TINGKAT I'),(29,'PENATA'),(30,'PENATA MUDA TINGKAT I'),(31,'PENATA MUDA'),(32,'PENGATUR TINGKAT I'),(33,'PENGATUR'),(34,'PENGATUR MUDA TINGKAT I'),(35,'PENGATUR MUDA'),(36,'JURU TINGKAT I'),(37,'JURU'),(38,'JURU MUDA TINGKAT I'),(39,'JURU MUDA');
/*!40000 ALTER TABLE `tb_pangkat` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_personil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_personil` (
  `id_personil` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(35) NOT NULL,
  `nrpnip` varchar(19) NOT NULL,
  `id_pangkat` int NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `id_kesatuan` int NOT NULL,
  `id_user` bigint unsigned DEFAULT NULL,
  `id_satker` int DEFAULT NULL,
  PRIMARY KEY (`id_personil`),
  KEY `id_user` (`id_user`),
  KEY `tb_personil_ibfk_1` (`id_pangkat`),
  KEY `tb_personil_ibfk_2` (`id_kesatuan`),
  KEY `id_satker` (`id_satker`),
  CONSTRAINT `tb_personil_ibfk_1` FOREIGN KEY (`id_pangkat`) REFERENCES `tb_pangkat` (`id_pangkat`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_personil_ibfk_2` FOREIGN KEY (`id_kesatuan`) REFERENCES `tb_kesatuan` (`id_kesatuan`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_personil_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_personil_ibfk_4` FOREIGN KEY (`id_satker`) REFERENCES `tb_satker` (`id_satker`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_personil` WRITE;
/*!40000 ALTER TABLE `tb_personil` DISABLE KEYS */;
INSERT INTO `tb_personil` VALUES (47,'MARIAH','78080909',12,'BA DITRESKRIMUM',11,71,13),(53,'DAVID ERNES','86071932',11,'SUBBAG',1,85,NULL),(54,'LUCKY','86071921',11,'KASUBBAG',1,85,33),(55,'RAMZI','86060017',14,'BANIT INTEL',1,85,NULL),(56,'BAYU','87060145',13,'KASIUM POLSEK SABAR MENANTI',1,176,33),(57,'GUSLIN SASWONDO','71090047',10,'KAPOLSEK',8,132,82),(58,'MARCUS LODEWIJK SIMANJUNTAK,S.H.','85081564',13,'BAMIN URMINTU',11,81,NULL),(59,'FAJAR','96070106',15,'BANIT INTEL',1,176,NULL),(65,'ERVIANA DWI MUSTIKA PUTRI','96010547',15,'BA SUBBAG RENMIN',11,78,20),(68,'ANDI CANDRA','79030038',11,'BA SUBBAGRENMIN DITPAMOBVIT',11,78,NULL),(70,'TANA AFRYANTA GINTING','98040115',16,'BAMIN BIRO LOGISTIK POLDA BENGKULU',11,67,9),(72,'ENDRI UTOMO SE','92110733',15,'BA SUBBAGRENMIN SATBRIMOBDA BENGKULU',11,74,16),(73,'YULI YENTI','198207282003122003',31,'PAMIN 7 SUBBAGRENMIN DITPAMOBVIT',11,78,20),(75,'FREZI FAHLEVI','87100360',13,'BAMIN RENMIN DITRESKRIMSUS POLDA BENGKULU',11,72,14),(76,'IRWAN','197609062003121002',28,'KAURMINTU SUBBAGRENMIN BIDHUMAS',11,61,3),(77,'TEGUH GUNAWAN','95030789',15,'BA URMINTU RO SDM POLDA BENGKULU',11,66,8),(78,'NONI','197205122002122003',27,'KASUBBAG PSIPERS BAG PSI RO SDM',1,176,33),(81,'PEMHAK','84030050',12,'BAURMIN SUBBAGRENMIN BIDKUM',11,62,4),(84,'MUHAMMAD THEZAR SYAMSUDDIN','00050237',16,'BA DITPOLAIRUD',11,79,21),(85,'SARTINI MULYAWATI','197711182002122001',31,'KAURMIN RUMKIT',11,83,25),(86,'alvi dwi arianda','95090328',15,'BA BIDDOKKES',11,83,25),(90,'M TRI QADLAYA,SH','79120974',9,'KAPOLSEK',9,123,73),(91,'WAWAN TEIANTORO','80090778',12,'PS KASIUM',9,123,73),(92,'SURIYONO,SH','79090232',11,'PS KANIT PROVOS',9,123,73),(93,'SUWAHYUDI','78020592',11,'KANIT INTEL',9,123,73),(94,'TH GULTOM','81051188',12,'KANIT BHIMAS',9,123,73),(95,'MS SIREGAR','78050274',13,'KANIT SHABARA',9,123,73),(96,'PUJI ANGRAINI','95070386',15,'BANIT PPA',9,123,73),(97,'SADUM WIJAYA','79040390',11,'BHABINKAMTIBMAS',9,123,73),(98,'SURYANTO','80070599',12,'BHABINKAMTIBMAS',9,123,73),(99,'TEGUH KURNIAWAN','86020887',13,'BHABINKAMTIBMAS',9,123,73),(100,'ARIE HIMAWAN','91010192',14,'BHABINKAMTIBMAS',9,123,73),(101,'HARMIN','93080219',14,'BHABINKAMTIBMAS',9,123,73),(102,'MUHAMED SADLI','92080741',15,'BHABINKAMTIBMAS',9,123,73),(103,'ALFAIZON','94110630',15,'BHABINKAMTIBMAS',9,123,73),(104,'BASRIL ANDESKO','94110972',15,'BHABINKAMTIBMAS',9,123,73),(106,'SUHERMAN','67010353',9,'KAPOLSEK',9,120,70),(107,'KUSWAHYUDI TRESNADI, S.H., S.I.K.','71070471',5,'KABIDPROPAM POLDA BENGKULU',11,60,2),(108,'JEFRI TAMPUBOLON, S.H.','85050104',12,'P.S. KAURREN SUBBAGRENMIN BIDPROPAM',11,60,2),(109,'MUHAMMAD SUNARYO','98040191',16,'BA SUBBAG RENMIN BIDPROPAM',11,60,2),(110,'ASWINDO INDRIADI, S.Kom., M.H.','85032030',8,'KAURLITPERS SUBBIDPAMINAL',11,60,2),(111,'INDRA G. MARBUN','85090615',13,'BA LITPERS SUBBIDPAMINAL',11,60,2),(112,'TAUFIK AKBAR, S.H.','92040096',14,'BA LITPERS SUBBIDPAMINAL',11,60,2),(113,'RUTHLIEN T. MALAU, S.H.','96090880',15,'BA LITPERS SUBBIDPAMINAL',11,60,2),(114,'SUMARTO, S.H. , M.H.','78050579',10,'PANIT I UNIT II  SUBBID PAMINAL',11,60,2),(115,'FIRMAN BAGUS PERDANA KUSUMA,S.Tr.K','96121125',10,'KAPOLSEK PENARIK RAYA',9,121,71),(116,'AHMAD APAN, S.H','79030163',11,'PS. KASIUM POLSEK PENARIK RAYA',9,121,71),(117,'MANDA LUBIS','77060169',11,'PS. KANIT SAMAPTA POLSEK PENARIK RAYA',9,121,71),(118,'EKO AGUS PRIHADI','79080407',11,'PS. KANIT INTELKAM POLSEK PENARIK RAYA',9,121,71),(119,'WAN SHIDDIK','80030513',12,'PS. KANIT BINMAS POLSEK PENARIK RAYA',9,121,71),(120,'AHMAD SUBIARIKSAN','82060200',12,'PS. KANIT RESKRIM POLSEK PENARIK RAYA',9,121,71),(121,'TAMIMI, S.H','86120333',13,'PS. KANIT PROVOST POLSEK PENARIK RAYA',9,121,71),(122,'WAHYUDIN','78120674',11,'BA UNIT LANTAS POLSEK PENARIK RAYA',9,121,NULL),(123,'RONI KURNIAWAN','78090424',11,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(124,'NOOR SAREH','80100044',12,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(125,'HOTNER SIDAURUK','82040123',12,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(126,'TOMY AB SINAGA','79090976',12,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(127,'EDU WARDO','84051408',13,'BA UNIT RESKRIM POLSEK PENARIK RAYA',9,121,71),(128,'LAHURI','90040371',14,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(129,'DEVID DWI PRATOMO','93120428',15,'BHABINKAMTIBMAS POLSEK PENARIK RAYA',9,121,71),(130,'IRFANSYAH DAMANIK','78070316',10,'Kapolsek V Koto',9,126,76),(131,'PEBRIADI','79020445',11,'PS.KANIT PATROLI',9,126,76),(133,'JANGGA P HARAHAP,SH','80030636',12,'PS.KASIUM',9,126,76),(134,'ISKANDAR Z,SH','79071214',12,'PS.KANIT RESKRIM',9,126,76),(135,'M.LUKMAN','80110414',12,'PS.KANIT INTELKAM',9,126,76),(136,'JONI HASTORI','83060285',12,'BHABINKAMTIBMAS',9,126,76),(137,'PAINO','83081047',13,'BHABINKAMTIBMAS',9,126,76),(138,'SANDY NP,AMd','85011697',13,'PS.KANIT BINMAS',9,126,76),(139,'ROMA DEVI','79080665',13,'BHABINKAMTIBMAS',9,126,76),(140,'RIKI PUTRANTO','88050807',14,'PS.KANIT PROVOST',9,126,76),(141,'MAHA PUTRA SEMBIRING','93010185',15,'BHABINKAMTIBMAS',9,126,76),(142,'HARRY J PURBA','93090477',15,'BHABINKAMTIBMAS',9,126,76),(143,'RUDINI PANCA','93010580',15,'BA POLSEK V KOTO',9,126,76),(144,'WIDI P','00060140',16,'BA SATRESKRIM',9,126,76),(145,'SUHARNO, S.H','84121590',13,'BHABINKAMTIBMAS POLSEK MANNA',4,143,56),(146,'FIQIH IQBAL A. ILLAHI, SH, MH','94080002',14,'KAURKEU BIRORENA',11,65,7),(147,'M.Setya Yuli.M','79070265',10,'Kapolsek',9,122,72),(148,'Dodik Raharjo Bintoro Aji','79100429',12,'KASIUM',9,122,72),(149,'Irwan Siregar','80050877',12,'Kanit Reskrim',9,122,72),(150,'Syaiful Anwar','80020471',12,'Kanit Provos',9,122,72),(151,'Yayat Hidayat','78110988',12,'Kanit Binmas',9,122,72),(152,'FRAN WAHYU ILLAHI','82070793',13,'Kanit Samapta',9,122,72),(153,'Bustan','83081484',13,'Kanit Intelkam',9,122,72),(154,'Seplin Winoto','83090227',12,'Bhabinkmatibmas',9,122,72),(155,'Deri Musnedi','87121211',14,'Banit Lantas',9,122,72),(156,'Bestari Harefa','85120998',13,'Bhabinkmatibmas',9,122,72),(157,'Yefli Nofrizaldo','85011557',13,'Banit Reskrim',9,122,72),(158,'Rudi Hartono','76010499',13,'Bhabinkmatibmas',9,122,72),(159,'Bayu Erlangga Kenedi','96070126',15,'Bhabinkmatibmas',9,122,72),(160,'Reki Lorenza','96090802',15,'Bhabinkmatibmas',9,122,72),(161,'MUHAMMAD IZAZI, S.Sos','77040066',12,'BA SUBBIDPAMINAL',11,60,2),(162,'AGUSTIAWAN','85081213',13,'BA SUBBIDPAMINAL',11,60,2),(163,'MUHAMMAD AZIM , S.M., M.M.','76070494',11,'PS. PANIT I PANIT III SUBBIDPAMINAL',11,60,2),(164,'ASIAN ARIEL SHARON SITORUS','82051333',13,'BA SUBBIDPAMINAL',11,60,2),(165,'ILHAM AKBAR PRATAMA','89030131',14,'BA BAG REN',8,181,557),(166,'ZUKOPLI KOMAINI','80110699',12,'BA SAT RESKRIM',8,182,558),(167,'ROBBY HAS WANTANIA, S.H.','85080745',10,'PAMIN RO SDM',11,66,8);
/*!40000 ALTER TABLE `tb_personil` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_satker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_satker` (
  `id_satker` int NOT NULL AUTO_INCREMENT,
  `satkers` varchar(100) NOT NULL,
  `id_kesatuan` int NOT NULL,
  PRIMARY KEY (`id_satker`),
  KEY `id_kesatuan` (`id_kesatuan`),
  CONSTRAINT `tb_satker_ibfk_1` FOREIGN KEY (`id_kesatuan`) REFERENCES `tb_kesatuan` (`id_kesatuan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=559 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_satker` WRITE;
/*!40000 ALTER TABLE `tb_satker` DISABLE KEYS */;
INSERT INTO `tb_satker` VALUES (1,'ITWASDA',11),(2,'BID PROPAM',11),(3,'BID HUMAS',11),(4,'BID HUKUM',11),(5,'BID TIPOL',11),(6,'RO OPS',11),(7,'RO RENA',11),(8,'RO SDM',11),(9,'RO SARPRAS',11),(10,'SET RBP DA',11),(11,'SPKT',11),(12,'DIT INTEL',11),(13,'DIT RESKRIMUM',11),(14,'DIT RESKRIMSUS',11),(15,'DIT NARKOBA',11),(16,'SAT BRIMOBDA',11),(17,'DIT BINMAS',11),(18,'DIT SABHARA',11),(19,'DIT LANTAS',11),(20,'DIT PAM OBVIT',11),(21,'DIT POLAIR',11),(22,'DIT TAHTI',11),(23,'SPN',11),(24,'BID KEU',11),(25,'BID DOKKES',11),(29,'RUMKIT BHAYANGKARA',11),(30,'SPRIPIM',11),(31,'SETUM',11),(32,'YANMA',11),(33,'POLSEK GADING CEMPAKA',1),(34,'POLSEK MUARA BANGKAHULU',1),(35,'POLSEK SELEBAR',1),(36,'POLSEK RATU SAMBAN',1),(37,'POLSEK TELUK SEGARA',1),(38,'KSKP PULAU BAAI',1),(39,'POLSEK RATU AGUNG',1),(40,'POLSEK KAMPUNG MELAYU',1),(41,'POLSEK KETAHUN',3),(42,'POLSEK PUTRI HIJAU',3),(43,'POLSEK LAIS',3),(44,'POLSEK PADANG JAYA',3),(45,'POLSEK ENGGANO',3),(46,'POLSEK GIRI MULYA',3),(47,'POLSEK NAPAL PUTIH',3),(48,'POLSEK KERKAP',3),(49,'POLSEK BATIK NAU',3),(50,'POLSEK AIR BESI',3),(51,'POLSEK KOTA MANNA',4),(52,'POLSEK PINO',4),(53,'POLSEK SEGINIM',4),(54,'POLSEK PINO RAYA',4),(55,'POLSEK KEDURANG',4),(56,'POLSEK MANNA',4),(57,'POLSEK PADANG ULAK TANDING',5),(58,'POLSEK KOTA CURUP',5),(59,'POLSEK SINDANG KELINCI',5),(60,'POLSEK KOTA PADANG',5),(61,'POLSEK BERMANI ULU',5),(62,'POLSEK BENGKO',5),(63,'POLSEK SELUMA',7),(64,'POLSEK SUKARAJA',7),(65,'POLSEK TALO',7),(66,'POLSEK SEMIDANG ALAS',7),(67,'POLSEK SEMIDANG ALAS MARAS',7),(68,'POLSEK MUKO-MUKO SELATAN',9),(69,'POLSEK MUKO-MUKO UTARA',9),(70,'POLSEK LUBUK PINANG',9),(71,'POLSEK PENARIK RAYA',9),(72,'POLSEK PONDOK SUGUH',9),(73,'POLSEK TERAS TERUNJAM',9),(74,'POLSEK TERAMANG JAYA',9),(75,'POLSEK SUNGAI RUMBAI',9),(76,'POLSEK V KOTO',9),(77,'POLSEK KAUR TENGAH',8),(78,'POLSEK KAUR SELATAN',8),(79,'POLSEK MUARA NASAL',8),(80,'POLSEK TANJUNG KEMUNING',8),(81,'POLSEK MAJE',8),(82,'POLSEK KAUR UTARA',8),(83,'POLSEK MUARA SAHUNG',8),(84,'POLSEK PADANG GUCI HULU',8),(85,'POLSEK KEPAHIANG',10),(86,'POLSEK UJAN MAS',10),(87,'POLSEK BERMANI ILIR',10),(88,'POLSEK TEBAT KARAI',10),(89,'POLSEK KABAWETAN',10),(90,'POLSEK LEBONG UTARA',6),(91,'POLSEK LEBONG SELATAN',6),(92,'POLSEK LEBONG ATAS',6),(93,'POLSEK RIMBO PENGADANG',6),(94,'POLSEK LEBONG TENGAH',6),(95,'POLSEK KARANG TINGGI',2),(96,'POLSEK TABA PENANJUNG',2),(97,'POLSEK TALANG EMPAT',2),(98,'POLSEK PONDOK KELAPA',2),(99,'POLSEK PAGAR JATI',2),(556,'BAG SDM POLRES BS',4),(557,'BAG REN POLRES KAUR',8),(558,'BA SAT RESKRIM',8);
/*!40000 ALTER TABLE `tb_satker` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_sigasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_sigasi` (
  `id_sigasi` int NOT NULL AUTO_INCREMENT,
  `id_personil` int NOT NULL,
  `jenis_penghargaan` varchar(100) DEFAULT NULL,
  `tingkat` varchar(50) DEFAULT NULL,
  `sumber` varchar(50) DEFAULT NULL,
  `nama_penghargaan` text,
  `nama_prestasi` text,
  `deskripsi` varchar(255) DEFAULT NULL,
  `tanggal_input` date DEFAULT NULL,
  `keterangan` varchar(30) DEFAULT NULL,
  `id_user` bigint unsigned NOT NULL,
  `file_bukti_surat` varchar(255) DEFAULT NULL,
  `extension_file_bukti_surat` varchar(255) DEFAULT NULL,
  `extension_deskripsi` varchar(10) DEFAULT NULL,
  `suratadmin` varchar(255) DEFAULT NULL,
  `extensionsuratadmin` varchar(10) DEFAULT NULL,
  `nosuratadmin` varchar(50) DEFAULT NULL,
  `no_file_bukti_surat` varchar(50) DEFAULT NULL,
  `keterangan_penghargaan` text,
  `jenis_surat` varchar(255) DEFAULT NULL,
  `jenissuratadmin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_sigasi`),
  KEY `id_personil` (`id_personil`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tb_sigasi_ibfk_1` FOREIGN KEY (`id_personil`) REFERENCES `tb_personil` (`id_personil`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tb_sigasi_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_sigasi` WRITE;
/*!40000 ALTER TABLE `tb_sigasi` DISABLE KEYS */;
INSERT INTO `tb_sigasi` VALUES (65,47,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-24','0',18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanda Penghargaan',NULL),(69,54,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-25','0',18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(71,53,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-25','0',85,NULL,NULL,NULL,'FILE SURAT PERMOHONAN POLRES.docx','docx',NULL,NULL,NULL,'Tanda Penghargaan','Tanda Penghargaan'),(72,53,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-25','0',18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(74,54,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-25','0',85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(75,53,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-26','0',85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(76,55,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-26','0',85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(77,56,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',176,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(78,59,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',176,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(81,72,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',74,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(83,78,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',176,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(85,70,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',67,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(86,86,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-27','0',83,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(87,107,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(88,108,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(89,109,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(90,110,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(91,111,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(92,112,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(93,113,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(94,114,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-28','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(95,145,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-29','0',143,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(96,146,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-29','0',65,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,161,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(98,162,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,163,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(100,161,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(101,164,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(102,163,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(103,161,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(104,164,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(105,163,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(106,161,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(107,164,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(108,163,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(109,161,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(110,164,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-01','0',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(111,165,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02','0',181,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(112,165,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02','0',181,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(113,166,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02','0',182,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(114,146,NULL,NULL,NULL,NULL,'PIAGAM PENGHARGAAN DIBERIKAN KEPADA RORENA POLDA BENGKULU (678300) ATAS PERINGKAT PERTAMA KATEGORI SATUAN KERJA TERBAIK DALAM KETEPATAN WAKTU DAN KELENGKAPAN DOKUMEN LAMPIRAN PENYAMPAIAN HARD COPY SPM TINGKAT SATUAN KERJA LINGKUP KPPN BENGKULU','CamScanner 10-29-2021 11.51.pdf','2021-11-09','1',65,'CamScanner 10-29-2021 11.39.pdf','pdf','pdf',NULL,NULL,NULL,'B/ND281-X-HAR-2021/Rorena',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tb_sigasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tb_validasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_validasi` (
  `id_validasi` int NOT NULL AUTO_INCREMENT,
  `id_sigasi` int NOT NULL,
  `status` int NOT NULL,
  `catatan_validasi` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_validasi`),
  KEY `id_sigasi` (`id_sigasi`),
  CONSTRAINT `tb_validasi_ibfk_1` FOREIGN KEY (`id_sigasi`) REFERENCES `tb_sigasi` (`id_sigasi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tb_validasi` WRITE;
/*!40000 ALTER TABLE `tb_validasi` DISABLE KEYS */;
INSERT INTO `tb_validasi` VALUES (59,65,1,'','2021-10-24 11:37:23','2021-10-24 11:37:23'),(60,65,1,NULL,'2021-10-24 11:38:47','2021-10-24 11:38:47'),(62,69,2,'hm','2021-10-25 02:38:41','2021-10-25 02:38:41'),(63,69,1,NULL,'2021-10-25 02:41:39','2021-10-25 02:41:39'),(65,71,1,NULL,'2021-10-25 05:30:59','2021-10-25 05:30:59'),(67,76,2,'TAMBAH BUKTI','2021-10-26 22:36:37','2021-10-26 22:36:37'),(68,76,2,'JELEK','2021-10-26 22:41:12','2021-10-26 22:41:12'),(69,76,1,NULL,'2021-10-26 22:43:51','2021-10-26 22:43:51'),(70,77,2,'BUKTI KURANG LENGKAP','2021-10-27 01:51:03','2021-10-27 01:51:03'),(71,78,2,'FILE BUKTI KURANG LENGKAP','2021-10-27 02:54:47','2021-10-27 02:54:47');
/*!40000 ALTER TABLE `tb_validasi` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `id_aktor` int NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_kesatuan` int NOT NULL,
  `id_satker` int DEFAULT NULL,
  `dekripsi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id_kesatuan` (`id_kesatuan`),
  KEY `id_aktor` (`id_aktor`),
  KEY `id_satker` (`id_satker`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_kesatuan`) REFERENCES `tb_kesatuan` (`id_kesatuan`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`id_satker`) REFERENCES `tb_satker` (`id_satker`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (18,'$2y$10$ieD0i8ylPbJQpIZ4FAMfEeQNYQawpPEvJgpYglYvQ6bQH/YXiLZx.','2021-10-08 02:52:30','2021-11-08 15:59:17',1,'POLDABENGKULU',1,8,'NONI'),(25,'$2y$10$kUyx8VuNv/zQVnao2bE6xeJQFO2sxatyARDAWJ7mZYp0.qBtPir7i','2021-10-09 01:25:15','2021-10-27 12:35:46',2,'POLRESBENGKULU',1,NULL,'QWERTY'),(26,'$2y$10$uvf3frL/DyomlOEZtgwNU.nWooBQg./w6yPe3ByM/A3sdOuyeJ0Ji','2021-10-09 01:25:43','2021-10-27 11:43:41',2,'POLRESBENGKULUTENGAH',2,NULL,'QWERTY'),(27,'$2y$10$iqintmIdjl3w/ZrcBrinRudhKCxM.TuySp5/j3fXbbBDmj0SKq0xG','2021-10-09 01:26:01','2021-10-27 11:44:15',2,'POLRESBENGKULUUTARA',3,NULL,'QWERTY'),(28,'$2y$10$WO5aZRmC.QgJlWK8OA77o.iA./Gk2Rhr5qiHcmQ2HlqmO19Sq/1Gi','2021-10-09 01:26:23','2021-10-27 11:44:25',2,'POLRESBENGKULUSELATAN',4,NULL,'QWERTY'),(29,'$2y$10$kOawuVGr4ODKk1KZjnZMv.jVaBxoZvsoVRkDUnA2SOzxnNPOv9wRK','2021-10-09 01:26:38','2021-10-27 11:44:35',2,'POLRESREJANGLEBONG',5,NULL,'QWERTY'),(30,'$2y$10$kneY/64p.EC5Rct3VGW.Zu7k4rJgYt7HaBMrXErl7YUxdTGvsbi8q','2021-10-09 01:27:04','2021-10-27 11:44:48',2,'POLRESLEBONG',6,NULL,'QWERTY'),(31,'$2y$10$EyCYmRPICmxWu2Ro4ZJpQOc589W9fxj9udyxh.wLjIeeJPsQf8lTC','2021-10-09 01:27:49','2021-10-27 11:45:23',2,'POLRESSELUMA',7,NULL,'QWERTY'),(32,'$2y$10$FsXz2ssbwipfaksTZG3n3.U/vjpg7AxY0USsA78gjySlyIZ06xtoi','2021-10-09 01:28:02','2021-10-27 11:45:30',2,'POLRESKAUR',8,NULL,'QWERTY'),(33,'$2y$10$52W5KbS7dwcZwKiCtc3wWuoUakoHmd.4qT1saHbDJeq9mb5P1urbK','2021-10-09 01:28:18','2021-10-27 11:45:41',2,'POLRESMUKO-MUKO',9,NULL,'QWERTY'),(34,'$2y$10$2UjyiN9uBG9jIex5imfRN.5RRrBGpZ4/eG4bRBkHX5P442PzcI5Si','2021-10-09 01:28:34','2021-10-27 11:45:50',2,'POLRESKEPAHIANG',10,NULL,'QWERTY'),(35,'$2y$10$xKur7jaZVMJE3QzCt.S/hON7QVfDYEPvI7CuJ/AYWNVw/XGKvWlte','2021-10-09 01:28:34','2021-10-27 12:34:23',3,'ITWASDA',11,1,'QWERTY'),(60,'$2y$10$lAdGLuW0Rzb33d1qf8B0NOcj4PBCe.CpBx0SD1T/0W4ykMPtbBAzu','2021-10-09 01:28:34','2021-10-27 11:49:42',3,'BIDPROPAM',11,2,'QWERTY'),(61,'$2y$10$6Qrgf.eSWqD55jWuDI3AR.P158tJwIMm.8QC.paX7kYkAdMPp45na','2021-10-09 01:28:34','2021-10-27 11:49:52',3,'BIDHUMAS',11,3,'QWERTY'),(62,'$2y$10$t3RAdZaSxm2DOpZlWXOBJ.I4d/EPJK/qAyDl33.fQt4wX93.YUjUC','2021-10-09 01:28:34','2021-10-27 11:50:49',3,'BIDHUKUM',11,4,'QWERTY'),(63,'$2y$10$mlje80sY1tAubjnzI4S64.DQ69s3t50BvOYOUpLy17UmWiteP.wLq','2021-10-09 01:28:34','2021-10-27 11:51:07',3,'BIDTIPOL',11,5,'QWERTY'),(64,'$2y$10$v..ao7Qb639DrDdRxsgOlupSxrF7mK.813VnRf5TVdnUbsTvEmYTS','2021-10-09 01:28:34','2021-10-27 11:51:18',3,'ROOPS',11,6,'QWERTY'),(65,'$2y$10$MagAiy3bI8VTU4z4CR/9EeIjTTdB3l8S.2.zu6lS43aXFDiXzu9j6','2021-10-09 01:28:34','2021-10-27 11:51:29',3,'RORENA',11,7,'QWERTY'),(66,'$2y$10$rCtFo9jfnLd6FkruiMpMxutZWREtqxjXObejaXnoip2V5K7ER8I8O','2021-10-09 01:28:34','2021-10-27 11:51:42',3,'ROSDM',11,8,'QWERTY'),(67,'$2y$10$8/Y8Gbw51cxqKXmv3Z2F1OsBYxBgv3SQkn7vq89I4bM5q1mwIMixC','2021-10-09 08:42:51','2021-10-27 11:51:51',3,'ROSARPRAS',11,9,'QWERTY'),(68,'$2y$10$ly758vlrOWWaRbKdNfba3ukW7nsyzC/ftvmSIs/Nh1EsFaXUyJvkC','2021-10-09 01:28:34','2021-10-27 11:52:01',3,'SETRBPDA',11,10,'QWERTY'),(69,'$2y$10$ZzXrNq3CpItyiJIK8OlyTOUWw2wQvxhtRbftpWFSoJYMBsEQa/FO.','2021-10-09 01:28:34','2021-10-27 11:52:12',3,'SPKT',11,11,'QWERTY'),(70,'$2y$10$sMC/BYuwwfDgr0jCq4n8q.q5lAxZmqPoyKjMl3vAje2f0RlSw3.6u','2021-10-09 01:28:34','2021-10-27 11:52:32',3,'DITINTEL',11,12,'QWERTY'),(71,'$2y$10$SjqK7hAhPzBm.fNSn1F3TOFBWJJKI29N5WDkexYmdCwZhsEKNcIgW','2021-10-09 01:28:34','2021-10-27 11:53:05',3,'DITRESKRIMUM',11,13,'QWERTY'),(72,'$2y$10$2pHBcO3nXqB6O.OXIXKDeu/MqEljSHO2R6K4rdRru4jjynlzkp22.','2021-10-09 01:28:34','2021-10-27 11:53:16',3,'DITRESKRIMSUS',11,14,'QWERTY'),(73,'$2y$10$oj4NwRrGu.6TGRCTjqMJ1enPAY1bG8ES4EkTUmxQIpYbC7haZ3gAm','2021-10-09 01:28:34','2021-10-27 11:53:33',3,'DITNARKOBA',11,15,'QWERTY'),(74,'$2y$10$HY.O2TwrcPdHivY.R/fkYuSdFFfkrlu/ZWycl0WFuq0HRLcOFpiGK','2021-10-09 01:28:34','2021-10-27 11:53:42',3,'SATBRIMOBDA',11,16,'QWERTY'),(75,'$2y$10$7VQaRimvxOgCKTdLDcI6V.iQ.EVDTlgb7s34uhpPHlNiO7IyGiB.C','2021-10-09 01:28:34','2021-10-27 11:53:54',3,'DITBINMAS',11,17,'QWERTY'),(76,'$2y$10$budG2LcH8SGIk3cNBoeTXuxi8Op0JXbhG5kOnW6MKseAdu0KPJVJK','2021-10-09 01:28:34','2021-10-27 11:54:05',3,'DITSABHARA',11,18,'QWERTY'),(77,'$2y$10$0d7xl/TBNANPIQCj9T4b.Om2Pocd4V0VUg/cSw5GKHrC.S3bAvY5G','2021-10-09 01:28:34','2021-10-27 11:54:18',3,'DITLANTAS',11,19,'QWERTY'),(78,'$2y$10$WkOPB3TQDXlIEtJg2xFvRuWZhb4OPaQikfQ.kF/A1WCF6snMm3m7W','2021-10-09 01:28:34','2021-10-27 11:54:32',3,'DITPAM OBVIT',11,20,'QWERTY'),(79,'$2y$10$mbS/CabRMDZKwiBCWmVyqOsfZ/CDivK3WH..PcRdjDe/sqerr5z5.','2021-10-09 01:28:34','2021-10-27 11:54:44',3,'DITPOLAIR',11,21,'QWERTY'),(80,'$2y$10$RCcPbiqADkMfnfDSmHMjHOSHzumTCOSN.ONLfnLEL13du/FoCvlya','2021-10-09 01:28:34','2021-10-27 11:54:56',3,'DITTAHTI',11,22,'QWERTY'),(81,'$2y$10$X7oHr5Ed6o5sfDQuR33D5OffOV6gpmxM7IkI0yC3jKm2mzBVZgPce','2021-10-09 01:28:34','2021-10-27 11:55:05',3,'SPN',11,23,'QWERTY'),(82,'$2y$10$F2GbTjGMO2OqlWxgV8LMRO5kI3LJyZ.HGmFo.0jN3L.wQF3disEgi','2021-10-09 01:28:34','2021-10-27 11:55:15',3,'BIDKEU',11,24,'QWERTY'),(83,'$2y$10$xV48E9WRoZys7NRUm0ZIieul6kk/vwrXLLYx4eNWv0DbjjRGdseMK','2021-10-09 01:28:34','2021-10-27 11:55:26',3,'BIDDOKKES',11,25,'QWERTY'),(84,'$2y$10$zUt5WBCg1wpLq3f3NdbmuehcOgmyHhEVr3SxqGxPiWqISVGmwUxzi','2021-10-09 02:21:41','2021-10-27 11:46:02',2,'BAGWATPERS',11,8,'QWERTY'),(85,'$2y$10$ouYjHwBVswNDCcAdNWI36O3BxZ/efBpHlMbOh/nVy1lbI1WFUQoRG','2021-10-09 03:45:52','2021-10-27 11:55:37',3,'POLSEKGADINGCEMPAKA',1,33,'QWERTY'),(87,'$2y$10$6fVDx8Q4qi34P3ArL8LVXOzZG3R1/o9RzRrZxy1EaqN3hPjcA245u','2021-10-09 15:57:30','2021-10-27 11:55:52',3,'POLSEKRATUAGUNG',1,39,'QWERTY'),(88,'$2y$10$QaBuMmuLDkKjlHoQexglF.ljWbAugZADPMf.Jc6M05RAcrA647Mcu','2021-10-10 06:06:22','2021-10-27 11:57:36',3,'POLSEKSELEBAR',1,35,'QWERTY'),(93,'$2y$10$6Qi4ktXbANRaIVuMQpeA5Ox2AFqzGeuZBkySEP3l8zNXb0.UkTWaK','2021-10-16 22:10:53','2021-10-27 11:57:48',3,'POLSEKMUARABANGKAHULU',1,34,'QWERTY'),(99,'$2y$10$xwLGtos0YQo2dLZ7UiLxze1/lMV5p/GKIB96wqWSFysPJXOpPXYIK',NULL,'2021-10-28 07:24:20',4,'ADMININFO',11,8,'QWERTY'),(103,'$2y$10$5iKaSoHGzNcHRuSVE4Jql.HaGEIhdgpAnFwe2Tpjs.Sp10ym6UxoW','2021-10-21 12:05:49','2021-10-27 11:58:04',3,'POLSEKTELUKSEGARA',1,37,'QWERTY'),(104,'$2y$10$dlhXygKPwK1Sx0NLEo9Zu.iofEo7o49gsLXA/NDWrhQPXmgrBSD8K','2021-10-22 15:58:35','2021-10-27 11:58:15',3,'SETUM',11,31,'QWERTY'),(106,'$2y$10$7YRbe/H10k0Zea9w3O9IQuHvOSKoaFwmk3ZC5nDv3lz/1sfEszel.','2021-10-22 16:06:56','2021-10-27 11:58:26',3,'RUMKITBHAYANGKARA',11,29,'QWERTY'),(108,'$2y$10$ZkrLegWSLLeWd.j0kHIo1OQ89/n9jrQ.fs0om5DJjgXYawnJTNTne','2021-10-22 16:13:53','2021-10-27 11:58:41',3,'SPRIPIM',11,30,'QWERTY'),(109,'$2y$10$itAeg3DsnlAcc7SjOc8FvuxO/nMGEI5BOfai/mQqVkhATNnZJLjqG','2021-10-22 16:14:40','2021-10-27 11:58:53',3,'YANMA',11,32,'QWERTY'),(113,'$2y$10$VgiBmO4MiXCRwPJs6nQRwO8I2nmRcJUgWK52AjPaOQNOniBsa3hVa','2021-10-25 00:31:49','2021-10-27 11:59:07',3,'POLSEKKEPAHIANG',10,85,'QWERTY'),(114,'$2y$10$Eoe00pVFBYDC08uw2FKJCeoLCBVIbapFo14H9rDyfsoXW24ppXiS6','2021-10-25 00:32:01','2021-10-27 11:59:19',3,'POLSEKUJANMAS',10,86,'QWERTY'),(115,'$2y$10$EcI9MOrE7v2etKDjvynzC.l.PYXp6vQEEcNTXSW/o2uHVBUTJX7V2','2021-10-25 00:34:14','2021-10-27 11:59:29',3,'POLSEKBERMANIILIR',10,87,'QWERTY'),(116,'$2y$10$R2HQy82lycsvoPgJoaYffOgiRTgKVb5Btu5o7GnEpkqQioROSs496','2021-10-25 00:34:27','2021-10-27 11:59:38',3,'POLSEKTEBATKARAI',10,88,'QWERTY'),(117,'$2y$10$QRyg/bKCWaPVUnT1zWSTe.HGJCTRGVvS9MjF2GmVcHxM4i66PvjFe','2021-10-25 00:35:09','2021-10-27 12:00:00',3,'POLSEKKABAWETAN',10,89,'QWERTY'),(118,'$2y$10$1z3Jvoj0jIhuLJPO9n48EOKJtx6vqH02yvah/.Pym8zq.rsIDVCmu','2021-10-25 00:37:42','2021-10-27 12:00:13',3,'POLSEKMUKO-MUKOSELATAN',9,68,'QWERTY'),(119,'$2y$10$oc6tC7YPTeYkksk5UjyITOEJHfOakvplwCXr7d3o3kDC/Tk3djeu2','2021-10-25 00:38:05','2021-10-27 12:00:53',3,'POLSEKMUKO-MUKOUTARA',9,69,'QWERTY'),(120,'$2y$10$vYtvHcSkXflVX1LHRwX/NOJ7r/UdBphE7H8WcziiXmx81jpEZbf5G','2021-10-25 00:38:20','2021-10-27 12:01:02',3,'POLSEKLUBUKPINANG',9,70,'QWERTY'),(121,'$2y$10$QLJ9KdWFhwa90xZp1FZL9eGAgovF1IHwAeKVmZjX9Pjo6IY/W.14y','2021-10-25 00:38:33','2021-10-27 12:01:17',3,'POLSEKPENARIKRAYA',9,71,'QWERTY'),(122,'$2y$10$rDwvbl15iL9NnhPOVy6cqudjWFquTZ1Zgk9KcLVoacNZHAwQSbd4S','2021-10-25 00:38:48','2021-10-27 12:01:28',3,'POLSEKPONDOKSUGUH',9,72,'QWERTY'),(123,'$2y$10$NRzB.vFtADtTo5wtwUTWeuxP02cjEx2sS05EMGzjK2VFn.OJFJE/W','2021-10-25 00:39:08','2021-10-27 12:01:42',3,'POLSEKTERASTERUNJAM',9,73,'QWERTY'),(124,'$2y$10$6Amb28P7pKu8Fdv7MbXhp.R6TMbnhpuzSEXyXjsXUkhN8sSFKeQeC','2021-10-25 00:39:25','2021-10-27 12:02:03',3,'POLSEKTERAMANGJAYA',9,74,'QWERTY'),(125,'$2y$10$RvjAEtEhFDcs80r0iUdPhOTuzW28ZthxpKd694AaFzc1AYkoMCcFK','2021-10-25 00:40:19','2021-10-27 12:02:26',3,'POLSEKSUNGAIRUMBAI',9,75,'QWERTY'),(126,'$2y$10$cGBCGRZ0IqeK1UlBJX0NAen1iM1INEK9KpV0K6UHqDQJJs1xFwRQG','2021-10-25 00:41:51','2021-10-27 12:02:57',3,'POLSEKVKOTO',9,76,'QWERTY'),(127,'$2y$10$ioWHnZfxU0DRbKNzT.C/yunedQdlQeRftjXNwLJ/Y6.W5IsnHEI5.','2021-10-25 00:42:34','2021-10-27 12:03:17',3,'POLSEKKAURTENGAH',8,77,'QWERTY'),(128,'$2y$10$MMvi8Aw4kC4gRPl2pzdBS.cHSTLUHKZFhZxay7JzXXlSSSzS34SfO','2021-10-25 00:52:39','2021-10-27 12:03:29',3,'POLSEKKAURSELATAN',8,78,'QWERTY'),(129,'$2y$10$E980aXVwQ8HuCLlNZ2f3U.j3wh374RAdTow/X1EUKeYI8PIbpG9hO','2021-10-25 00:52:51','2021-10-27 12:03:41',3,'POLSEKMUARANASAL',8,79,'QWERTY'),(130,'$2y$10$gCj/PPXv.1b5zw7gnPHeFes0T0CeQQZ4UCNx5jfKWZfFREVvi3FzS','2021-10-25 00:53:04','2021-10-27 12:03:55',3,'POLSEKTANJUNGKEMUNING',8,80,'QWERTY'),(131,'$2y$10$QnmGWEasYFWRUPxL7paoIOCCLfYvs4q7QkMHM8l5I5v04WbUbGr8a','2021-10-25 00:57:20','2021-10-27 12:04:04',3,'POLSEKMAJE',8,81,'QWERTY'),(132,'$2y$10$6PRyuQq2CjrOubYGocpt5.TydRGDyTS7BF6PIOYwhauo46IKVN1MG','2021-10-25 00:58:25','2021-10-27 12:04:13',3,'POLSEKKAURUTARA',8,82,'QWERTY'),(133,'$2y$10$cocVv3jeEOQle/VKZQTx.u/fvGTNHJ7eOYQHlw0P14GgfjlbTttB6','2021-10-25 00:58:40','2021-10-27 12:04:23',3,'POLSEKMUARASAHUNG',8,83,'QWERTY'),(134,'$2y$10$/gIWgCsoOOhGBHLCl0fry.LTD3ZIJSJAOKFgEDQVB2gU24te5WKnG','2021-10-25 00:59:27','2021-10-27 12:04:49',3,'POLSEKPADANGGUCIHULU',8,84,'QWERTY'),(135,'$2y$10$2IzwoqS09cQCBJem9DvhMO3Im44ovxy6n8gQccNgsxNTV7TX1Phv2','2021-10-25 02:54:10','2021-10-27 12:05:33',3,'KSKPPULAUBAAI',1,38,'QWERTY'),(136,'$2y$10$xGpw5DDRgcpGm0NlsxN0euJfNPlwGwirB8Bipb.AKboVv3gZCAWjG','2021-10-25 02:54:36','2021-10-27 12:05:45',3,'POLSEKRATUSAMBAN',1,36,'QWERTY'),(137,'$2y$10$eMIGv1UN1kQt7zakXMRuBuaeutYxIOFVEnqZ9zEcUluNxnOwiqZjG','2021-10-25 02:54:56','2021-10-27 12:06:02',3,'POLSEKKAMPUNGMELAYU',1,40,'QWERTY'),(138,'$2y$10$.LTubFT.W0.jhSbe74fpm.UxD1ThheNNnBa.gb6UyAg/majbqJ01y','2021-10-25 03:27:49','2021-10-27 12:06:12',3,'POLSEKKOTAMANNA',4,51,'QWERTY'),(139,'$2y$10$JjRos8PvSSYiMHB9iQV4cuo5oIYd2uRKWXUfx8Ae0TirRH2qTFZea','2021-10-25 03:28:01','2021-10-27 12:08:54',3,'POLSEKPINO',4,52,'QWERTY'),(140,'$2y$10$dNuGDPXQqikihM7rLv4Ci.FRaL2a/Kl/nca.W/qpx2J72kvysTPuW','2021-10-25 03:28:12','2021-10-27 12:09:05',3,'POLSEKSEGINIM',4,53,'QWERTY'),(141,'$2y$10$g7x0BT7XhmnnOCgWxeKx4OPN5SQ75hS4zqkqkZ33cE39O1JJAXIAS','2021-10-25 03:28:28','2021-10-27 12:09:27',3,'POLSEKKEDURANG',4,55,'QWERTY'),(142,'$2y$10$XLFXOOi0mY8I/19eqkD0TeSLhvUKE2PyKVjKe17Z.5IkaBWTA5nt.','2021-10-25 03:28:57','2021-10-27 12:09:44',3,'POLSEKPINORAYA',4,54,'QWERTY'),(143,'$2y$10$t2m8nOTR7Oh7fF5zSSmPxOwTSRD3F6JTHr/RpXPc.7yPsaOhAmBtq','2021-10-25 03:29:09','2021-10-27 12:10:01',3,'POLSEKMANNA',4,56,'QWERTY'),(144,'$2y$10$4zbdjNbCCn.BOfzHyqARNuxyBLKm/nBG8BPOoQAWV6DOSH8pKgp7O','2021-10-25 03:38:52','2021-10-27 12:10:16',3,'POLSEKKARANGTINGGI',2,95,'QWERTY'),(145,'$2y$10$wWhgN7GhcKoO1wLpozzTPuzOrhfNBviN6fzow.O82XNqChQdCGUMm','2021-10-25 03:39:05','2021-10-27 12:10:28',3,'POLSEKTABAPENANJUNG',2,96,'QWERTY'),(146,'$2y$10$EqTHR80jaMHIMhe5kIbX0OLy7j7YJitss2LsPLXb6NqVRXodl6AoK','2021-10-25 03:39:23','2021-10-27 12:10:46',3,'POLSEKTALANGEMPAT',2,97,'QWERTY'),(147,'$2y$10$0VyIiouaPuCKTzrlb6WBZevzbZsBhNyvtc/BatCH87N2n3XXja9km','2021-10-25 03:39:38','2021-10-27 12:10:58',3,'POLSEKPONDOKKELAPA',2,98,'QWERTY'),(148,'$2y$10$ghh9cLFOS1ttWncn6zdMwOHf89qwV9DAZJ7QzmVG52K5g/pv.1zO6','2021-10-25 03:39:50','2021-10-27 12:11:08',3,'POLSEKPAGARJATI',2,99,'QWERTY'),(149,'$2y$10$jfeR7AkTqxykE1lymG5wruIBSy/LwPQEySPiwP86Vqg3MZZIhmHRG','2021-10-25 03:58:05','2021-10-27 12:11:16',3,'POLSEKKETAHUN',3,41,'QWERTY'),(150,'$2y$10$I.tOowpJnGPDgxknKMbmh.rPBAXUNJicm9Iyf4atE.DHfvOjmR2Q2','2021-10-25 03:58:20','2021-10-27 12:11:30',3,'POLSEKPUTRIHIJAU',3,42,'QWERTY'),(151,'$2y$10$puNN4yGp0r/HxGtoHhYSVOR6LnRmI3novZTl4VsFk3M0NrV0vyLTe','2021-10-25 03:58:29','2021-10-27 12:11:42',3,'POLSEKLAIS',3,43,'QWERTY'),(152,'$2y$10$l5sSwjY8VV4ZtKhw8c9LvuRxbFM84RXIgnP2yBlOBwHxUcnHS278e','2021-10-25 03:58:46','2021-10-27 12:12:03',3,'POLSEKPADANGJAYA',3,44,'QWERTY'),(153,'$2y$10$IevLI17vi0uHo1YfY30SdOXdrkAF6VuZZpF07LUZgwG0fvseBO9a6','2021-10-25 03:59:03','2021-10-27 12:12:14',3,'POLSEKENGGANO',3,45,'QWERTY'),(154,'$2y$10$F6IrWwwaT8KulKqiar40N.mej9shYE0wkmDC22X3zFnjBFCaPpvy.','2021-10-25 03:59:18','2021-10-27 12:12:26',3,'POLSEKGIRIMULYA',3,46,'QWERTY'),(155,'$2y$10$6OpSdFSyYOeJWvQ040n14ODQfFrc3lnJMp1FDJUqa7RZaEfxbEgjK','2021-10-25 03:59:34','2021-10-27 12:12:41',3,'POLSEKNAPALPUTIH',3,47,'QWERTY'),(156,'$2y$10$rbjX45Bl99yIhcR6R0sp7O0PDHsg6dDbZ8cKcnKdS87RL/HMJTl9.','2021-10-25 03:59:58','2021-10-27 12:12:54',3,'POLSEKKERKAP',3,48,'QWERTY'),(157,'$2y$10$AP741lKSrqyVPpgmzcFGTukL4T553nsp1f.36YlTf4kO2uPr5qmJ2','2021-10-25 04:00:09','2021-10-27 12:13:11',3,'POLSEKBATIKNAU',3,49,'QWERTY'),(158,'$2y$10$VRNtYsvwdUVixN6T9bZJH.All7n9G7CIT1aKyw3zk6z5YF/khxUla','2021-10-25 04:00:20','2021-10-27 12:13:23',3,'POLSEKAIRBESI',3,50,'QWERTY'),(159,'$2y$10$eCaxba68.zFVcNI7.4roQuWzHzzSCZaNNsu/Z0nBYkc/gVRsp6YBi','2021-10-25 04:07:38','2021-10-27 12:13:43',3,'POLSEKPANDANGULAKTANDING',5,57,'QWERTY'),(160,'$2y$10$MGeGhJhXoTniZAonsaB2Bu4Y7ihIs8RnpzhnAU9qMCRdypsay4PtG','2021-10-25 04:07:54','2021-10-27 12:14:34',3,'POLSEKKOTACURUP',5,58,'QWERTY'),(161,'$2y$10$3oHhe8Py1STHnwmSoqvzgu2.4PgUK71gtn9o/NNSmgcJjSoAPPLLu','2021-10-25 04:08:11','2021-10-27 12:14:45',3,'POLSEKSINDANGKELINCI',5,59,'QWERTY'),(162,'$2y$10$yvZW7iHxjUAJ3.FY0adKuuaPsW3NoXDYvGZbvxUf7./h7OcXcz3Wy','2021-10-25 04:08:44','2021-10-27 12:14:59',3,'POLSEKKOTAPADANG',5,60,'QWERTY'),(163,'$2y$10$rFYc24zIertaFqURUhCDGu1SPNBYGGxueXQvVbpqmuxecZB8jNXFy','2021-10-25 04:08:58','2021-10-27 12:15:21',3,'POLSEKBERMANIULU',5,61,'QWERTY'),(164,'$2y$10$LQRejMiU0.lA4YSnrfGDFeIyvN6NUcAeR1n3uZyHesf.qaKxF5Ym6','2021-10-25 04:09:11','2021-10-27 12:15:43',3,'POLSEKBENGKO',5,62,'QWERTY'),(165,'$2y$10$HVVTAcqGxX225a2j0Uhb.e9Rn4BftDr6.jO.hAiEqp8pd/Sl/VA32','2021-10-25 04:11:08','2021-10-27 12:16:19',3,'POLSEKLEBONGUTARA',6,90,'QWERTY'),(166,'$2y$10$Crl3IVZDdWdlSznpMBI9QeRh1bQ.sV589..veOKJ8Ir1.t9nQoGci','2021-10-25 06:04:16','2021-10-27 12:16:31',3,'POLSEKLEBONGSELATAN',6,91,'QWERTY'),(167,'$2y$10$CxdQr42OgRB2800J2b8roekvvOkF./lDiXKLo4Gs2wo7i7ASIT9tK','2021-10-25 06:04:51','2021-10-27 12:16:44',3,'POLSEKLEBONGATAS',6,92,'QWERTY'),(168,'$2y$10$UXFc7SBl86o74SQ3OlYrG.ed1zNI4JGKgA.zv6YI91k1XxLQoRy2q','2021-10-25 06:05:19','2021-10-27 12:16:57',3,'POLSEKRIMBOPENGADANG',6,93,'QWERTY'),(169,'$2y$10$3nKLMrp43N1O5uLnZLb4ruiS0MKS1dR42BKq8qzIwlaVR7mEalt5G','2021-10-25 06:05:48','2021-10-27 12:17:08',3,'POLSEKLEBONGTENGAH',6,94,'QWERTY'),(170,'$2y$10$eqODC6lf0zR/t0CJ.oCbs.KN29SjGOFjl9EC.vKXg4ya0kEo37g9K','2021-10-25 06:06:35','2021-10-27 12:17:18',3,'POLSEKSELUMA',7,63,'QWERTY'),(171,'$2y$10$M/h7QuDGMp11aRPOtddIG.0YMrQQSxH4JYINx7luS9lKXlGdqv.Iu','2021-10-25 06:07:08','2021-10-27 12:17:29',3,'POLSEKSUKARAJA',7,64,'QWERTY'),(172,'$2y$10$Jy8cR6Kut6RTcigzVqawH./kGWP0CUEoiNpiTXaFnI9yHYH8RDpEK','2021-10-25 06:07:31','2021-10-27 12:17:41',3,'POLSEKTALO',7,65,'QWERTY'),(173,'$2y$10$2W6f/gxPCCekKJKjLok50OApD0E/HhaiPiwyGGrl/KHU4KKfqxALm','2021-10-25 06:08:04','2021-10-27 12:17:53',3,'POLSEKSEMIDANGALAS',7,66,'QWERTY'),(174,'$2y$10$9RNY4vXHvUwektx/db1PO.3A55uTIWFMcuUdzh1bqJv59No3gOJUS','2021-10-25 06:08:28','2021-10-27 12:18:02',3,'POLSEKSEMIDANGALASMARAS',7,67,'QWERTY'),(175,'$2y$10$B1Wu0JS/cvbvBk1KoUi1Pemywu4pKiYkjSrvS/TeSlO8xSnbe2ioC','2021-10-27 01:35:22','2021-10-27 12:28:01',2,'ADMINSIMULASI',1,NULL,'QWERTY'),(176,'$2y$10$XPfRVNK7ZauQHwym662K7edUUauj4GRZnv9W23rgdvsVg7DPjOzCe','2021-10-27 01:37:40','2021-10-27 12:27:24',3,'USERSIMULASI',1,33,'QWERTY'),(179,'$2y$10$tLMAQW4Yoo9XAl6Fl.uXauva4w/W/t3btuNjPUOgYTwKo6I02DVH.','2021-10-28 01:55:11','2021-10-28 01:55:11',3,'BAGSDMPOLRESBS',4,556,'QWERTY'),(181,'$2y$10$V6tCnA3Z2KMsZT3mN8D4W.dq1bLSlh2Pg5SB83A81JAtVmjwLQ.VS','2021-11-02 03:27:33','2021-11-02 03:28:49',3,'JUPICOVARIZI',8,557,'QWERTY'),(182,'$2y$10$Tbv.gJswQwf1DI89LAgrR.ymg0b5yKb4WKWQCoy/8XiBS8KG5EyA2','2021-11-02 03:56:39','2021-11-02 03:56:39',3,'RONIANDIKO',8,558,'QWERTY');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

